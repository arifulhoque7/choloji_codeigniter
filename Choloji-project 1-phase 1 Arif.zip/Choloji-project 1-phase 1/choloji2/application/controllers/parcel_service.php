<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parcel_service extends CI_Controller {

	public function __construct(){
		parent:: __construct();

		if (!isset($_SESSION['authenticate'])) {
			redirect(base_url());
		}
	}
	

	public function show_all_delivers(){
		$data=array();
		$data['all_deliver'] = $this->parcel_model->get_delivers();
		$data['admin_main_content']=$this ->load->view('parcel service/all_delivers',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_vendors(){
		$data=array();
		$data['all_vendors'] = $this->parcel_model->get_vendors();
		$data['admin_main_content']=$this ->load->view('parcel service/vendors',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_customers(){
		$data=array();
		$data['all_customers'] = $this->parcel_model->get_customers();
		$data['admin_main_content']=$this ->load->view('parcel service/customers',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_delivery_man(){
		$data=array();
		$data['all_delivery_man'] = $this->parcel_model->get_deliveryman();
		$data['admin_main_content']=$this ->load->view('parcel service/delivery_man',$data,true);
		$this->load->view('dashboard',$data);
	}	
	

		public function save_vendor(){
		$data=array();
		$this->parcel_model->save_vendor_info();
		$sdata=array();
		$sdata ['message'] = 'vendor added successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-vendors');
	}

	public function save_driveryman(){
		$data=array();
		$this->parcel_model->save_driveryman_info();
		$sdata=array();
		$sdata ['message'] = 'driveryman added successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-delivery-man');
	}
}