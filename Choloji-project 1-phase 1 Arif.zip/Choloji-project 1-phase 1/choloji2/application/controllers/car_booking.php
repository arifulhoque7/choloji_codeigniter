<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Car_booking extends CI_Controller {

	public function __construct(){
		parent:: __construct();

		if (!isset($_SESSION['authenticate'])) {
			redirect(base_url());
		}
	}
	public function show_car_list(){
		$data=array();
		$data['car_options'] = array('Microcar','A-segment','B-segment','C-segment','D-segment',
								'E-segment ','E-segment ','Mini MPV','Compact MPV','Large MPV','Premium compact','luxury compact','mid-size luxury','full-size luxury'); 
		$data['all_car_details'] = $this->car_model->get_cars();
		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';

		$data['admin_main_content']=$this ->load->view('cars/car_list',$data,true);
		
		$this->load->view('dashboard',$data);
	}	

	public function show_car_list_json(){

		header('Content-type:application/json;charset=utf-8');
		
		$data["details"] = $this->car_model->get_cars();

		echo json_encode($data);
			
	}

	public function show_car_ride(){
		$data=array();
		$data['all_car_rides'] = $this->car_model->get_rides();
		$data['admin_main_content']=$this ->load->view('cars/car_ride',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_car_drivers(){

		$data=array();
		$data['all_driver_details'] = $this->car_model->get_drivers();
		$data['admin_main_content']=$this ->load->view('cars/car_drivers',$data,true);
		$this->load->view('dashboard',$data);
	}


		public function show_driver_list_json(){
		header('Content-type:application/json;charset=utf-8');	
		$data["details"] = $this->car_model->get_drivers();
		echo json_encode($data);
			
	}
	
	public function show_car_passengers(){
		$data=array();
		$data['all_car_passengers'] = $this->car_model->get_passengers();
		$data['admin_main_content']=$this ->load->view('cars/car_passengers',$data,true);
		$this->load->view('dashboard',$data);
	}	


	//ekhane car save hobe
	public function save_car(){
		$data=array();
		$this->car_model->save_car_info();
		$sdata=array();
		$sdata ['message'] = 'car added successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-car-list');
	}
	public function save_driver(){
		$data=array();
		$this->car_model->save_driver_info();
		$sdata=array();
		$sdata ['message'] = 'driver added successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-car-drivers');
	}
	//ekhane car delete hobe
	public function delete_car($car_id){
		$deleted = $this->car_model->delete_car_info($car_id);
		// $data=array();
		$sdata=array();
		$sdata ['message1'] = 'car deleted successfully!!';
		$this->session->set_userdata($sdata);
	
		redirect('show-car-list');
	}
	public function delete_car_driver($car_driver_id){
		$deleted = $this->car_model->delete_car_driver_info($car_driver_id);
		// $data=array()	
		$sdata=array();
		$sdata ['message1'] = 'driver deleted successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-car-drivers');
	}
	
}