<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		// if (isset($_SESSION['authenticate'])) {
		// 	redirect('dashboard');
		// }
	}


	public function admin_login()
	{
		if (isset($_SESSION['authenticate'])) {
			redirect('dashboard');
		}

		$username = $this->input->post('username',true);
		$password = $this->input->post('password',true);

		$this->load->model('admin_model');
		$result = $this->admin_model->admin_model_info($username,$password);
		$sdata =array();

		if ($result) {
			$sdata['admin_id'] =$result->admin_id;
			$sdata['admin_name'] =$result->admin_name;
			$sdata['authenticate'] =TRUE;

			$this->session->set_userdata($sdata);
			redirect('dashboard');
		}else{
			$sdata['message'] = 'Your email or password Invaid';
			$this->session->set_userdata($sdata);
			redirect(base_url()); 
		}
	}

		public function logout(){
		$this->session->unset_userdata('admin_id');
		$this->session->unset_userdata('admin_name');
		session_destroy();
		$sdata['logout_message'] ='logout successfully';
		$this->session->set_userdata($sdata);
		redirect(base_url());
	}


	// public function backend(){
	// 	$this->load->view('admin_login');
	// }
		public function auth(){
		if (!isset($_SESSION['authenticate'])) {
			redirect(base_url());
		}
		}



		public function dashboard(){
		$this->auth();

		$data = array();
		$data['admin_main_content']=$this ->load->view('pages/admin_index','',true);
		$this->load->view('dashboard',$data);
	}
	
	public function show_car(){
		$this->auth();
		$data=array();
		$data['admin_main_content']=$this ->load->view('pages/show_car','',true);
		$this->load->view('dashboard',$data);
	}
		public function show_bike(){
		$this->auth();
		$data=array();
		$data['all_bike_info'] = $this->admin_model->all_bike_info();

		$data['admin_main_content']=$this ->load->view('pages/show_bike',$data,true);
		$this->load->view('dashboard',$data);
	}

	public function delete_bike($id){
		echo "asche";
		$this->auth();
		$this->admin_model->delete_bike_by($id);
		$sdata=array();
		print_r($id);
		$sdata['message'] = "Booking information deleted successfully!!";
		$this->session->set_userdata($sdata);
		redirect('show-bike');
	}

		public function show_microbus(){
		$this->auth();
		$data=array();
		$data['admin_main_content']=$this ->load->view('pages/show_microbus','',true);
		$this->load->view('dashboard',$data);
	}
		public function show_ambulance(){
		$this->auth();
		$data=array();
		$data['admin_main_content']=$this ->load->view('pages/show_ambulance','',true);
		$this->load->view('dashboard',$data);
	}
		public function show_helicopter(){
		$this->auth();
		$data=array();
		$data['admin_main_content']=$this ->load->view('pages/show_helicopter','',true);
		$this->load->view('dashboard',$data);
	}
	public function show_cng(){
		$this->auth();
		$data=array();
		$data['admin_main_content']=$this ->load->view('pages/show_cng','',true);
		$this->load->view('dashboard',$data);
	}
	public function show_rickshaw(){
		$this->auth();
		$data=array();
		$data['admin_main_content']=$this ->load->view('pages/show_rickshaw','',true);
		$this->load->view('dashboard',$data);
	}
}
