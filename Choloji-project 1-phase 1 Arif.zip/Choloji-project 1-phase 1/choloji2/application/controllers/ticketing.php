<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ticketing extends CI_Controller {

	public function __construct(){
		parent:: __construct();

		if (!isset($_SESSION['authenticate'])) {
			redirect(base_url());
		}
	}
	public function show_ticket_booking_list(){
		$data=array();
		$data['all_booking_list'] = $this->ticketing_model->get_booking_list();
		$data['admin_main_content']=$this ->load->view('ticketing/booking',$data,true);
		$this->load->view('dashboard',$data);
	}	

	//vendor start
	public function show_bus_vendor_list(){
		$data=array();
		$data['all_bus_vendors'] = $this->ticketing_model->get_bus_vendor_list();
		$data['admin_main_content']=$this ->load->view('ticketing/bus/travel_vendors',$data,true);
		$this->load->view('dashboard',$data);
	}
	//vendor finish

	//passengers start 

	public function show_bus_passenger_list(){
		$data=array();
		$data['all_bus_passengers'] = $this->ticketing_model->get_bus_passenger_list();
		$data['admin_main_content']=$this ->load->view('ticketing/bus/passengers',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_train_passenger_list(){
		$data=array();
		$data['all_train_passengers'] = $this->ticketing_model->get_train_passenger_list();
		$data['admin_main_content']=$this ->load->view('ticketing/train/passengers',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_launch_passenger_list(){
		$data=array();
		$data['all_launch_passengers'] = $this->ticketing_model->get_launch_passenger_list();
		$data['admin_main_content']=$this ->load->view('ticketing/launch/passengers',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_airlines_passenger_list(){
		$data=array();
		$data['all_airlines_passengers'] = $this->ticketing_model->get_airlines_passenger_list();
		$data['admin_main_content']=$this ->load->view('ticketing/airlines/passengers',$data,true);
		$this->load->view('dashboard',$data);
	}	

	//passengers finish


	public function save_bus_travel_vendor(){
		$data=array();
		$this->ticketing_model->save_bus_vendor_info();
		$sdata=array();
		$sdata ['message'] = 'vendor added successfully!! Please add bus information by clicking <h3> Add bus </h3> button';
		$this->session->set_userdata($sdata);
		redirect('show-bus-vendor-list');
	}
	public function save_ticketing_bus(){
		$data=array();
		$this->ticketing_model->save_bus_info();
		$sdata=array();
		$sdata ['message'] = 'car added successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-bus-vendor-list');
	}
}