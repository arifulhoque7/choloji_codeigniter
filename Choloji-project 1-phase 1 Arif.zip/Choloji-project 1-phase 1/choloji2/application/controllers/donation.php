<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Donation extends CI_Controller {

	public function __construct(){
		parent:: __construct();

		if (!isset($_SESSION['authenticate'])) {
			redirect(base_url());
		}
	}

	public function show_donation_transaction_list(){
		$data=array();
		$data['all_donation_details'] = $this->donation_model->get_donation_details();
		$data['admin_main_content']=$this ->load->view('donation/transaction',$data,true);
		$this->load->view('dashboard',$data);
	}

	public function show_old_donor_list(){
		$data=array();
		$data['all_old_donor_details'] = $this->donation_model->get_old_donor_details();
		$data['admin_main_content']=$this ->load->view('donation/donor/old_donation',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_orphanage_donor_list(){
		$data=array();
		$data['all_orphanage_donor_details'] = $this->donation_model->get_orphanage_donor_details();
		$data['admin_main_content']=$this ->load->view('donation/donor/orphanage',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_mosque_donor_list(){
		$data=array();
		$data['all_mosque_donor_details'] = $this->donation_model->get_mosque_donor_details();
		$data['admin_main_content']=$this ->load->view('donation/donor/mosque',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_madrasha_donor_list(){
		$data=array();
		$data['all_madrasha_donor_details'] = $this->donation_model->get_madrasha_donor_details();
		$data['admin_main_content']=$this ->load->view('donation/donor/madrasha',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_zaqat_donor_list(){
		$data=array();
		$data['all_zaqat_donor_details'] = $this->donation_model->get_zaqat_donor_details();
		$data['admin_main_content']=$this ->load->view('donation/donor/zaqat',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_quarbani_donor_list(){
		$data=array();
		$data['all_quarbani_donor_details'] = $this->donation_model->get_quarbani_donor_details();
		$data['admin_main_content']=$this ->load->view('donation/donor/quarbani',$data,true);
		$this->load->view('dashboard',$data);
	}
	
	public function show_old_recipient_list(){
		$data=array();
		$data['all_old_recipient_details'] = $this->donation_model->get_old_recipient_details();
		$data['admin_main_content']=$this ->load->view('donation/recipient/old_donation',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_orphanage_recipient_list(){
		$data=array();
		$data['all_orphanage_recipient_details'] = $this->donation_model->get_orphanage_recipient_details();
		$data['admin_main_content']=$this ->load->view('donation/recipient/orphanage',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_mosque_recipient_list(){
		$data=array();
		$data['all_mosque_recipient_details'] = $this->donation_model->get_mosque_recipient_details();
		$data['admin_main_content']=$this ->load->view('donation/recipient/mosque',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_madrasha_recipient_list(){
		$data=array();
		$data['all_madrasha_recipient_details'] = $this->donation_model->get_madrasha_recipient_details();
		$data['admin_main_content']=$this ->load->view('donation/recipient/madrasha',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_zaqat_recipient_list(){
		$data=array();
		$data['all_zaqat_recipient_details'] = $this->donation_model->get_zaqat_recipient_details();
		$data['admin_main_content']=$this ->load->view('donation/recipient/zaqat',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function show_quarbani_recipient_list(){
		$data=array();
		$data['all_quarbani_recipient_details'] = $this->donation_model->get_quarbani_recipient_details();
		$data['admin_main_content']=$this ->load->view('donation/recipient/quarbani',$data,true);
		$this->load->view('dashboard',$data);
	}

}