<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Food extends CI_Controller {

	public function __construct(){
		parent:: __construct();

		if (!isset($_SESSION['authenticate'])) {
			redirect(base_url());
		}
	}

	public function show_food_sales(){
		$data=array();
		$data['all_food_sale'] = $this->food_model->get_food_sale();
		$data['admin_main_content']=$this ->load->view('food/sales',$data,true);
		$this->load->view('dashboard',$data);
	}	

	public function show_food_restaurant(){
		$data=array();
		$data['all_food_restaurant'] = $this->food_model->get_food_restaurant();
		$data['admin_main_content']=$this ->load->view('food/restaurant',$data,true);
		$this->load->view('dashboard',$data);
	}	

	public function show_food_customer(){
		$data=array();
		$data['all_food_customer'] = $this->food_model->get_food_customer();
		$data['admin_main_content']=$this ->load->view('food/customer',$data,true);
		$this->load->view('dashboard',$data);
	}	
	public function show_food_foodlist(){
		$data=array();
		$data['all_food_foodlist'] = $this->food_model->get_food_foodlist();
		$data['admin_main_content']=$this ->load->view('food/foodlist',$data,true);
		$this->load->view('dashboard',$data);
	}

	public function show_food_delivery_man(){
		$data=array();
		$data['all_delivery_man'] = $this->food_model->get_food_deliveryman();
		$data['admin_main_content']=$this ->load->view('food/delivery_man',$data,true);
		$this->load->view('dashboard',$data);
	}
	public function save_food_driveryman(){
		$data=array();
		$this->food_model->save_food_driveryman_info();
		$sdata=array();
		$sdata ['message'] = 'driveryman added successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-food-delivery-man');
	}
	public function save_food_restaurant(){
		$data=array();
		$this->food_model->save_food_restaurant_info();
		$sdata=array();
		$sdata ['message'] = 'restaurant added successfully!!';
		$this->session->set_userdata($sdata);
		redirect('show-food-restaurant');
	}
}