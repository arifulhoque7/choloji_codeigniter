<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">
<div class="row page-titles">
	<div class="col-md-5 align-self-center">
		<h3 class="text-themecolor" style="font-family:'Montserrat', sans-serif ;">Delivery Man</h3>

	</div>
	<div class="col-md-7 align-self-center">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
			<li class="breadcrumb-item">Parcel Service</li>
			<li class="breadcrumb-item active" >Delivery Man</li>
		</ol>
	</div>
	<div>
		<!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
	</div>
</div>

<div class="container-fluid">
	<!-- ============================================================== -->
	<!-- Start Page Content -->
	<!-- ============================================================== -->
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<h4 class="card-title" >Delivery Man List</h4>
					<!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
					<button type="button" class="btn btn-dark btn-sm" data-toggle="modal" data-target="#add-type-vehicule" style="font-family:'Montserrat', sans-serif ; margin-bottom: 10px;"><i class="fa fa-plus m-r-10"></i>Add</button>
					<div id="add-type-vehicule" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg">
							<div class="modal-content bg-gris">
								<div class="modal-header">
									<h4 class="modal-title" id="myModalLabel">Add a Delivary man</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<form class="form-horizontal " action="<?php base_url();?>save-driveryman" method="post" enctype="multipart/form-data">
									<div class="modal-body">
										<div class="form-group">
											<div class="row">
												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Delivary man name</label>
														<input type="text" class="form-control " placeholder="" name="deliveryman_name" required> 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>
												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Phone</label>
														<input type="number" class="form-control " placeholder="" name="deliveryman_phone" required> 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>
												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">National ID no.</label>
														<input type="number" class="form-control " placeholder="" name="deliveryman_nid" required> 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>
												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Image</label>
														<input type="file" class="form-control " placeholder="" name="deliveryman_photo" id="image_vehicule" required> 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="modal-footer">
										<button type="submit" class="btn btn-dark waves-effect" style="font-family:'Montserrat', sans-serif ;">Save</button>
										<button type="button" class="btn btn-default waves-effect" data-dismiss="modal" style="font-family:'Montserrat', sans-serif ;">Cancel</button>
									</div>
								</form>
							</div>
							<!-- /.modal-content -->
						</div>
						<!-- /.modal-dialog -->
					</div>

					<?php
					$message = $this->session->userdata('message');

					if ($message) {
						?>
						<div class="alert alert-success" style="font-family:'Montserrat', sans-serif;font-weight: 700;">
							<?php echo $message ?> 
						</div>
						<?php
						$this->session->unset_userdata('message');
					}
					?> 


					<div class="table-responsive m-t-10">
						<table id="" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th width="5%">N°</th>
									<th width="10%">Photo</th>
									<th width="10%">Name</th>
									<th width="10%">Phone</th>
									<th width="10%">National card number</th>
									<th width="5%">Created</th>
									
								</tr>
							</thead>
							<tbody>

								<?php foreach($all_delivery_man as $deliveryman):?>
									<tr>
										<td><?php echo  $deliveryman->deliveryman_id  ?></td>
										<td>
											<div class="user-profile" style="width:100%;">
												<div class="profile-img" style="width:100%;"><img src="<?php echo $deliveryman->deliveryman_photo ?>" alt="deliveryman_image" width="100%" style="width:auto;height:70px;"></div>
											</div>
										</td>
										<td><?php echo  $deliveryman->deliveryman_name ?></td>
										<td><?php echo  $deliveryman->deliveryman_phone ?></td>
										<td><?php echo  $deliveryman->deliveryman_nid ?></td>
										<td><?php echo  $deliveryman->created_date ?></td>
									</tr>
								<?php endforeach; ?>

							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
