<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">
<div class="row page-titles">
	<div class="col-md-5 align-self-center">
		<h3 class="text-themecolor" style="font-family:'Montserrat', sans-serif ;">All delivers</h3>

	</div>
	<div class="col-md-7 align-self-center">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
			<li class="breadcrumb-item">Parcel Service</li>
			<li class="breadcrumb-item active" >All delivers</li>
		</ol>
	</div>
	<div>
		<!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
	</div>
</div>

<div class="container-fluid">
	<!-- ============================================================== -->
	<!-- Start Page Content -->
	<!-- ============================================================== -->
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<h4 class="card-title" >Deliver list</h4>
					<!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
					<div class="table-responsive m-t-10">
						<table id="" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th>N°</th>
									<th width="10%">From</th>
									<th width="10%">To</th>
									<th>Customer</th>
									<th>Venodor</th>
									<!-- <th>Status</th> -->
									<th>Delivery Man</th>
									<th>Distance</th>
									<th>Charge Amount</th>
									<th>Payment Status</th>
									<th>Payment Method</th>
									<th>Rating</th> 
								</tr>
							</thead>
							<tbody>	

								<?php foreach($all_deliver as $deliver):?>
									<tr>
										<td><?php echo  $deliver->deliver_id  ?></td>
										<td><?php echo  $deliver->deliver_from ?></td>
										<td><?php echo  $deliver->deliver_to ?></td>
										<td><?php echo  $deliver->customer?></td>
										<td><?php echo  $deliver->vendor?></td>
										<td><?php echo  $deliver->delivery_man ?></td>
										<td><?php echo  $deliver->distance ?></td>
										<td><?php echo  $deliver->charge_amount ?></td>
										<td><?php echo  $deliver->payment_status ?></td>
										<td><?php echo  $deliver->payment_method ?></td>
										<td><?php echo  $deliver->rating ?></td>
									</tr>
								<?php endforeach; ?>

							</tbody>

						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
