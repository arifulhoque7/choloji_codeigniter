<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-themecolor" style="font-family:'Montserrat', sans-serif ;">All vendors</h3>
        
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item">Parcel Service</li>
            <li class="breadcrumb-item active" >Vendors</li>
        </ol>
    </div>
    <div>
        <!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
    </div>
</div>

<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title" >Vendor list</h4>
                    <!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
                    <button type="button" class="btn btn-dark btn-sm" data-toggle="modal" data-target="#add-type-vehicule" style="font-family:'Montserrat', sans-serif ; margin-bottom: 10px;"><i class="fa fa-plus m-r-10"></i>Add</button>
                    <div id="add-type-vehicule" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content bg-gris">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="myModalLabel">Add a Vendor</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                </div>
                                <form class="form-horizontal " action="<?php base_url();?>save-vendor" method="post" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Name of the Company </label>
                                                        <input type="text" class="form-control " placeholder="" name="company_name" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Address</label>
                                                        <input type="text" class="form-control " placeholder="" name="address" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Contact Number</label>
                                                        <input type="number" class="form-control " placeholder="" name="contact_number" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Business License No </label>
                                                        <input type="number" class="form-control " placeholder="" name="license_no" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Number of Years in business </label>
                                                        <input type="number" class="form-control " placeholder="" name="number_of_year" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div> 

                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Vendor Type</label>
                                                        <input type="text" class="form-control " placeholder="" name="vendor_type" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-dark waves-effect" style="font-family:'Montserrat', sans-serif ;">Save</button>
                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal" style="font-family:'Montserrat', sans-serif ;">Cancel</button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                    
                    <?php
                    $message = $this->session->userdata('message');

                    if ($message) {
                      ?>
                      <div class="alert alert-success" style="font-family:'Montserrat', sans-serif;font-weight: 700;">
                         <?php echo $message ?> 
                     </div>
                     <?php
                     $this->session->unset_userdata('message');
                 }
                 ?> 

                 <div class="table-responsive m-t-10">
                    <table id="" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th width="10%">Name of the Company</th>
                                <th width="10%">Address</th>
                                <th>Contact Number</th>
                                <th>Business License No</th>
                                <th>Number of Years in business</th>   
                                <th>Vendor Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($all_vendors as $vendor):?>

                                <tr>
                                    <td><?php echo  $vendor->vendor_id  ?></td>
                                    <td><?php echo  $vendor->vendor_name ?></td>
                                    <td><?php echo  $vendor->vendor_address ?></td>
                                    <td><?php echo  $vendor->vendor_contact ?></td>
                                    <td><?php echo  $vendor->vendor_license ?></td>
                                    <td><?php echo  $vendor->vendor_year ?></td>
                                    <td><?php echo  $vendor->vendor_type ?></td>
                                </tr>
                            <?php endforeach; ?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
