<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">
<div class="row page-titles">
	<div class="col-md-5 align-self-center">
		<h3 class="text-themecolor" style="font-family:'Montserrat', sans-serif ;">All Orphanage Donor List</h3>

	</div>
	<div class="col-md-7 align-self-center">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
			<li class="breadcrumb-item">Donation</li>
			<li class="breadcrumb-item">Donor</li>
			<li class="breadcrumb-item active">Orphanage</li>
		</ol>
	</div>
	<div>
		<!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
	</div>
</div>

<div class="container-fluid">
	<!-- ============================================================== -->
	<!-- Start Page Content -->
	<!-- ============================================================== -->
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<h4 class="card-title">Donor list</h4>
					<!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
					<div class="table-responsive m-t-10">
						<table id="" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th>N°</th>
									<th>Donor</th>
									<th>Address</th>
									<th>Email</th>
									<th>Phone</th>
									<th>Amount</th>
								</tr> 
							</thead>
							<tbody>
								<?php foreach($all_orphanage_donor_details as $donor):?>
									<tr>
										<td><?php echo  $donor->donor_id  ?></td>
										<td><?php echo  $donor->donor_name?></td>
										<td><?php echo  $donor->donor_address?></td>
										<td><?php echo  $donor->donor_email?></td>
										<td><?php echo  $donor->donor_phone?></td>
										<td><?php echo  $donor->donor_amount?></td>							
									</tr>
								<?php endforeach; ?> 
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
