<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">

<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-themecolor">Vehicles</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item">Booking Service</li>
            <li class="breadcrumb-item">Vehicles</li>
            <li class="breadcrumb-item active">Car</li>
        </ol>
    </div>
    <div>
        <!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">List of cars</h4>
                    <!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
                    <button type="button" class="btn btn-dark btn-sm" data-toggle="modal" data-target="#add-type-vehicule" style="font-family:'Montserrat', sans-serif ; margin-bottom: 10px;"><i class="fa fa-plus m-r-10"></i>Add</button>
                    <div id="add-type-vehicule" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content bg-gris">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="myModalLabel">Add a vehicle</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                </div>
                                <form class="form-horizontal " action="<?php base_url();?>save-car" method="post" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Name</label>
                                                        <input type="text" class="form-control " placeholder="" name="car_name" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Cost/KM</label>
                                                        <input type="number" class="form-control " placeholder="" name="car_cost" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 m-b-0" style="font-family:'Montserrat', sans-serif ;" >
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Image</label>
                                                        <input type="file" class="form-control " placeholder="" name="car_image" id="image_vehicule" >
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Car class</label>
                                                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" style="font-family:'Montserrat', sans-serif ;" name = "car_class" >
                                                           <option selected >Select a Class</option>

                                                           <?php foreach ($car_options as $car_option){ ?>
                                                              <option value="<?php echo $car_option;?>" <?php echo set_select ('car_option',$car_option); ?>><?php echo $car_option; ?> </option>
                                                          <?php } ?>  

                                                      </select>
                                                  </div>
                                              </div>


                                              <div class="col-md-12 m-b-0">
                                                <div class="form-group mb-3">
                                                    <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Booking type</label>
                                                    <input type="text" class="form-control " placeholder="" name="car_booking_type" required> 
                                                    <div class="invalid-feedback">
                                                        Désolé, entrez l'intitulé de la catégorie de devis
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 m-b-0">
                                                <div class="form-group mb-3">
                                                    <label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Service Cost </label>
                                                    <input type="number" class="form-control " placeholder="" name="car_service_cost" required> 
                                                    <div class="invalid-feedback">
                                                        Désolé, entrez l'intitulé de la catégorie de devis
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-dark waves-effect" style="font-family:'Montserrat', sans-serif ;">Save</button>
                                    <button type="button" class="btn btn-default waves-effect" data-dismiss="modal" style="font-family:'Montserrat', sans-serif ;">Cancel</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                   <!--  <div id="type-vehicule-mod" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content bg-gris">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="myModalLabel">Modify a vehicle type</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                </div>
                                <form class="form-horizontal " action="query/action.php" method="post" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <div class="row">
                                                <input type="hidden" name="id_type_vehicule_mod" id="id_type_vehicule_mod" value="1">
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation">Name</label>
                                                        <input type="text" class="form-control " placeholder="" name="libelle_type_vehicule_mod" id="libelle_type_vehicule_mod" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation">Cost/KM</label>
                                                        <input type="number" class="form-control " placeholder="" name="price_vehicule_mod" id="price_vehicule_mod" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 m-b-0">
                                                    <div class="form-group mb-3">
                                                        <label class="mr-sm-2" for="designation">Image</label>
                                                        <input type="file" class="form-control " placeholder="" name="image_vehicule_mod" id="image_vehicule_mod" required> 
                                                        <div class="invalid-feedback">
                                                            Désolé, entrez l'intitulé de la catégorie de devis
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-dark waves-effect">Save</button>
                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                            </div>  
                        </div>
                    </div> -->

                    <?php
                    $message = $this->session->userdata('message');

                    if ($message) {
                      ?>
                      <div class="alert alert-success" style="font-family:'Montserrat', sans-serif;font-weight: 700;">
                       <?php echo $message ?> 
                   </div>
                   <?php
                   $this->session->unset_userdata('message');
               }
               ?> 

                <?php
                    $message1 = $this->session->userdata('message1');

                    if ($message1) {
                      ?>
                      <div class="alert alert-danger" style="font-family:'Montserrat', sans-serif;font-weight: 700;">
                         <?php echo $message1 ?> 
                     </div>
                     <?php
                     $this->session->unset_userdata('message1');
                 }
                 ?> 


               <div class="table-responsive m-t-10">
                <table id="example24" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Name</th>
                            <th>Cost/KM ($)</th>
                            <th>Image</th>
                            <th>Class</th>
                            <th>Booking type</th>
                            <th>Service Cost</th>
                            <th>Created</th>
                            <th width="2%">Actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php foreach($all_car_details as $car):?>

                            <tr>

                                <td><?php echo  $car->car_id  ?></td>
                                <td><?php echo  $car->car_name ?></td>
                                <td><?php echo  $car->car_cost ?></td>
                                <td>
                                    <div class="user-profile" style="width:100%;">
                                        <div class="profile-img" style="width:100%;"><img src="<?php echo $car->car_image ?>" alt="car_image" width="100%" style="width:auto;height:70px;"></div>
                                    </div>

                                </td>
                                <!--  <td><img src = "<?php echo $car->car_image ?>" > </td> -->
                                <td><?php echo  $car->car_class?></td>
                                <td><?php echo  $car->car_booking_type ?></td>
                                <td><?php echo  $car->car_service_cost ?></td>
                                <td><?php echo  $car->created ?></td>


                                <td>
                                    <input type="hidden" value="167" name="" id="id_affectation_0">
                                    <a href="<?php echo base_url();?>delete-car/<?php echo $car->car_id?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-original-title="Delete" onclick= "return confirm('Are you sure to delete this entry?')"> <i class="fa fa-trash"></i> </a>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<!-- ============================================================== -->
<!-- End PAge Content -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Right sidebar -->
<!-- ============================================================== -->
<!-- .right-sidebar -->

</div>
<!-- ============================================================== -->
            <!-- End Container fluid  -->