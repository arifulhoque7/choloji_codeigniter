<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">

<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-themecolor">Rides</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item">Booking Service</li>
            <li class="breadcrumb-item">All rides</li>
            <li class="breadcrumb-item active">Car</li>
        </ol>
    </div>
    <div>
        <!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">List of Rides</h4>

                    <div class="table-responsive m-t-10">
                        <table id="example24" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
                         <thead>
                            <tr>
                                <th>N°</th>
                                <th>Rider</th>
                                <th>Driver</th>
                                <th>To</th>
                                <th>From</th>
                                <th>Bill</th>
                                <th>Rate</th>
                                <th>Created</th>
                                
                            </tr>
                        </thead>
                        <tbody>

                            
                                <?php foreach($all_car_rides as $ride):?>

                                    <tr>

                                        <td><?php echo  $ride->ride_id  ?></td>
                                        <td><?php echo  $ride->rider_name ?></td>
                                        <td><?php echo  $ride->driver_name ?></td>
                                        <td><?php echo  $ride->loc_to ?></td>
                                        <td><?php echo  $ride->loc_from ?></td>
                                        <td><?php echo  $ride->bill ?></td>
                                        <td><?php echo  $ride->rate ?></td>
                                        <td><?php echo  $ride->created ?></td>


                                    </tr>
                                <?php endforeach; ?>

                                  <!--   <td>
                                        <input type="hidden" value="1" name="" id="id_categorie_user_0">
                                        <button type="button" onclick="modCategorieUser(id_categorie_user_0.value);" class="btn btn-warning btn-sm" data-original-title="Modify" data-toggle="modal" data-target="#categorie-user-mod"><i class="fa fa-pencil"></i></button>
                                        <a href="query/action.php?id_categorie_user=1" class="btn btn-danger btn-sm" data-toggle="tooltip" data-original-title="Delete"> <i class="fa fa-trash"></i> </a>
                                    </td> -->
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->

</div>
<!-- ============================================================== -->
            <!-- End Container fluid  -->