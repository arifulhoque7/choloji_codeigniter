<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">
<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-themecolor" style="font-family:'Montserrat', sans-serif ;">Passenger</h3>
        
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item">Booking Service</li>
            <li class="breadcrumb-item">Passengers</li>
            <li class="breadcrumb-item active" >Car</li>
        </ol>
    </div>
    <div>
        <!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
    </div>
</div>

<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title" >Passenger list</h4>
                    <!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
                    <div class="table-responsive m-t-10">
                        <table id="" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Photo</th>
                                    <th> Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                             <?php foreach($all_car_passengers as $passenger):?>
                                <tr>
                                    <td><?php echo  $passenger->car_pass_id ?></td>
                                    <td>
                                    <div class="user-profile" style="width:100%;">
                                        <div class="profile-img" style="width:100%;">
                                            <img src="<?php echo base_url();?>/front-end/images/1.jpg" alt="pics " width="100%" style="width:70px;height:70px;"></div>
                                    </div>
                                    </td>
                                    <td><?php echo  $passenger->car_pass_name ?></td>
                                    <td><?php echo  $passenger->car_pass_email ?></td>
                                    <td><?php echo  $passenger->car_pass_phone ?></td>
                                    <td><?php echo  $passenger->car_pass_created ?></td>
                                </tr>
                            <?php endforeach; ?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
