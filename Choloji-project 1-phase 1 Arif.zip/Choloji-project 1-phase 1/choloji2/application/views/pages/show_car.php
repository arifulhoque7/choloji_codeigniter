<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h3 class="text-themecolor">Customer</h3>
    </div>
    <div class="col-md-7 align-self-center">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item">User of APP</li>
            <li class="breadcrumb-item active">Customer</li>
        </ol>
    </div>
    <div>
        <!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
    </div>
</div>

<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Customers list</h4>
                    <!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
                    <div class="table-responsive m-t-10">
                        <table id="example24" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Photo</th>
                                    <th>Last & First Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Modified</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <tr>
                                    <td>1</td>
                                    <td>
                                        <div class="user-profile" style="width:100%;">
                                            <div class="profile-img" style="width:100%;"><img src="on_demand_taxi_webservice/images/app_user/user_profile.jpg" alt="" width="100%" style="width:70px;height:70px;"></div>
                                        </div>
                                    </td>
                                    <td> Customer</td>
                                    <td></td>
                                    <td>+12345678910</td>
                                    <td><span class="badge badge-success">yes</span></td>
                                    <td>2019-11-30 09:05:14</td>
                                    <td>0000-00-00 00:00:00</td>
                                    <td>
                                        <input type="hidden" value="15" name="" id="id_affectation_0">
                                        <a href="query/action.php?id_user_app_activer=15" class="btn btn-success btn-sm" data-toggle="tooltip" data-original-title="Enable"> <i class="fa fa-check"></i> </a>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>2</td>
                                    <td>
                                        <div class="user-profile" style="width:100%;">
                                            <div class="profile-img" style="width:100%;"><img src="on_demand_taxi_webservice/images/app_user/user_profile.jpg" alt="" width="100%" style="width:70px;height:70px;"></div>
                                        </div>
                                    </td>
                                    <td> Anik</td>
                                    <td></td>
                                    <td>01644442233</td>
                                    <td><span class="badge badge-success">yes</span></td>
                                    <td>2020-12-13 22:04:57</td>
                                    <td></td>
                                    <td>
                                        <input type="hidden" value="16" name="" id="id_affectation_1">
                                        <a href="query/action.php?id_user_app_activer=16" class="btn btn-success btn-sm" data-toggle="tooltip" data-original-title="Enable"> <i class="fa fa-check"></i> </a>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>3</td>
                                    <td>
                                        <div class="user-profile" style="width:100%;">
                                            <div class="profile-img" style="width:100%;"><img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fin.pinterest.com%2Fpin%2F813392382683605534%2F&psig=AOvVaw2LLQvZQl8bahGSR038INEA&ust=1613541209526000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCKD_4cfb7e4CFQAAAAAdAAAAABAD" alt="" width="100%" style="width:70px;height:70px;"></div>
                                        </div>
                                    </td>
                                    <td>Khandakar Shakil</td>
                                    <td></td>
                                    <td>01822583158</td>
                                    <td><span class="badge badge-success">yes</span></td>
                                    <td>2021-02-12 05:28:00</td>
                                    <td>2021-02-13 13:33:07</td>
                                    <td>
                                        <input type="hidden" value="17" name="" id="id_affectation_2">
                                        <a href="query/action.php?id_user_app_activer=17" class="btn btn-success btn-sm" data-toggle="tooltip" data-original-title="Enable"> <i class="fa fa-check"></i> </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>