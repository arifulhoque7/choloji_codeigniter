	<div class="row">
		<div class="col-md-12">
			<div class="bgc-white bd bdrs-3 p-20">
				<h4 class="c-grey-900 mB-20">Rickshaw Booking Database</h4>
				<table class="table table-hover">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col">Name</th>
							<th scope="col">Pickup Location</th>
							<th scope="col">Number of Passenger</th>
							<th scope="col">Pickup Date/Time</th>
							<th scope="col">Passenger Mobile No</th>
							<th scope="col">Driver name</th>
							<th scope="col">Driver Mobile no</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<th scope="row">1</th>
							<td>Mark</td>
							<td>Otto</td>
							<td>@mdo</td>
							<td>Mark</td>
							<td>Otto</td>
							<td>@mdo</td>
							<td>@mdo</td>
							<td><button type="button" class="btn btn-success">Edit</button>
								<button type="button" class="btn btn-danger">Delete</button></td>
						</tr>
						<tr>
							<th scope="row">2</th>
							<td>Jacob</td>
							<td>Thornton</td>
							<td>@fat</td>
							<td>Jacob</td>
							<td>Thornton</td>
							<td>@fat</td>
							<td>@mdo</td>
							<td><button type="button" class="btn btn-success">Edit</button>
							<button type="button" class="btn btn-danger">Delete</button></td>
						</tr>
						<tr>
							<th scope="row">3</th>
							<td>Thornton</td>
							<td>@fat</td>
							<td>Jacob</td>
							<td>Thornton</td>
							<td>@fat</td>
							<td>@twitter</td>
							<td>@mdo</td>
							<td><button type="button" class="btn btn-success">Edit</button>
								<button type="button" class="btn btn-danger">Delete</button></td>

						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>