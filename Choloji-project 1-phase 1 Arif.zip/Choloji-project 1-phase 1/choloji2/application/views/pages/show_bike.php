	<div class="row">
		<div class="col-md-12">
			<div class="bgc-white bd bdrs-3 p-20">
				<h4 class="c-grey-900 mB-20">Bike Booking Database</h4>
 				<?php
				  $message = $this->session->userdata('message');

				  if ($message) {
				  ?>
				  	<div class="alert alert-danger" >
  					 <?php echo $message ?> 
					</div>
					<?php
				  	$this->session->unset_userdata('message');
				  }
				 ?>

				<table id="datatable1" class="table table-hover">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col">Name</th>
							<th scope="col">Pickup Location</th>
							<th scope="col">Number of Passenger</th>
							<th scope="col">Pickup Date</th>
							<th scope="col">Pickup time</th>
							<th scope="col">Passenger Mobile No</th>
							<th scope="col">Driver name</th>
							<th scope="col">Driver Mobile no</th>
							<th scope="col">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						foreach ($all_bike_info as $v_bike){

						?>
						<tr>
							<th scope="row"><?php echo $v_bike->id ?></th>
							<td><?php echo $v_bike->name ?> </td>
							<td><?php echo $v_bike->pickup_location ?> </td>
							<td><?php echo $v_bike->number_of_passenger?> </td>
							<td><?php echo $v_bike->pickup_date ?> </td>
							<td><?php echo $v_bike->pickup_time?> </td>
							<td><?php echo $v_bike->p_mobile?> </td>
							<td><?php echo $v_bike->driver_name?> </td>
							<td><?php echo $v_bike->d_mobile?> </td>



							<td>
								<button type="button" class="btn btn-success">Edit</button>
								<a button type="button" class="btn btn-danger" href="<?php echo base_url();?>delete-bike/<?php echo $v_bike->id ?>">Delete</button>


							    <a button type="button" class="btn btn-danger" href="javascript:void(0);" onclick="delete(<?php echo $v_bike->id;?>);">Delete</a>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<script type="text/javascript">
    var url="<?php echo base_url();?>";
    function delete(id){
       var r=confirm("Do you want to delete this?")
        if (r==true)
          window.location = url+"delete-bike/"+id;
        else
          return false;
        } 
    </script>