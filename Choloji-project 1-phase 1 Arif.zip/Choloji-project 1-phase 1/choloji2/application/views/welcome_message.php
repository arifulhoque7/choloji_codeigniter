<!DOCTYPE html>
<html>
<!-- Mirrored from colorlib.com/polygon/adminator/signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Feb 2021 10:32:27 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->
<head>
	<title> Admin Sign In</title>
	<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">
</head>
<body class="app">
	<div id="loader">
		<div class="spinner"></div>
	</div>
	<script type="text/javascript">

		window.addEventListener('load', () => {
			const loader = document.getElementById('loader');
			setTimeout(() => {
				loader.classList.add('fadeOut');
			}, 300);
		});</script>
		<div class="peers ai-s fxw-nw h-100vh">
			<div class="d-n@sm- peer peer-greed h-100 pos-r bgr-n bgpX-c bgpY-c bgsz-cv" style="background-image:url(front-end/images/bmw.jpg)">
				<div class="pos-a centerXY">
					<div class="bgc-white bdrs-50p pos-r" style="width:120px;height:120px">
						<img class="pos-a centerXY" src="front-end/images/logo.png" alt="">
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 peer pX-40 pY-80 h-100 bgc-white scrollable pos-r" style="min-width:320px">
				<h4 class="fw-300 c-grey-900 mB-40" style="color:#000066;font-family:'Montserrat', sans-serif;font-weight: bold;">Admin Login</h4>

				<?php
				  $message = $this->session->userdata('message');

				  if ($message) {
				  ?>
				  	<div class="alert alert-danger" style="font-family:'Montserrat', sans-serif;font-weight: 700;">
  					 <?php echo $message ?> 
					</div>
					<?php
				  	$this->session->unset_userdata('message');
				  }
				 ?>

				 <?php
				  $message = $this->session->userdata('logout_message');

				  if ($message) {
				  ?>
				  	<div class="alert alert-success" >
  					 <?php echo $message ?> 
					</div>
					<?php
				  	$this->session->unset_userdata('logout_message');
				  }
				 ?>

				<form action="<?php echo base_url()?>admin-login" method= "post">
					<div class="form-group">
						<label class="text-normal text-dark"  style="color:#000066;font-family:'Montserrat', sans-serif;font-weight: 600;" >Username</label>
						<input type="text" class="form-control" name= "username" placeholder="Type your Username" style="font-family:'Montserrat', sans-serif;">
					</div>
					<div class="form-group">
						<label class="text-normal text-dark"  style="color:#000066;font-family:'Montserrat', sans-serif;font-weight: 600;" >Password</label>
						<input type="password" class="form-control" name= "password" placeholder="Type your Password" style="font-family:'Montserrat', sans-serif;">
					</div>
					<div class="form-group">
						<div class="peers ai-c jc-sb fxw-nw">
							<div class="peer">
								<div class="checkbox checkbox-circle checkbox-info peers ai-c">
									<input type="checkbox" id="inputCall1" name="inputCheckboxesCall" class="peer">
									<label for="inputCall1" class="peers peer-greed js-sb ai-c">
										<span class="peer peer-greed"  style="color:#000066;font-family:'Montserrat', sans-serif;font-weight: 600;" >Remember Me</span>
									</label>
								</div>
							</div>
							<div class="peer">
								<button type="submit" class="btn btn-primary"  style="font-family:'Montserrat', sans-serif;font-weight: 600;">Login</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		<script type="text/javascript" src="front-end/js/vendor.js"></script>
		<script type="text/javascript" src="front-end/js/bundle.js"></script>
	</body>
	<!-- Mirrored from colorlib.com/polygon/adminator/signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Feb 2021 10:32:28 GMT -->
	</html>
