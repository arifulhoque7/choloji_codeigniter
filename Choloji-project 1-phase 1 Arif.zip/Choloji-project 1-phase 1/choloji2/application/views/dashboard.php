<!DOCTYPE html>
<html>
<!-- Mirrored from colorlib.com/polygon/adminator/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Feb 2021 10:32:11 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->
<head>
	<title>Dashboard</title>
	<style></style>
	<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.23/datatables.min.css"/>



</head>
<body class="app">
	<div id="loader">
		<div class="spinner"></div>
	</div>
	

	<div>
		<div class="sidebar">
			<div class="sidebar-inner">
				<div class="sidebar-logo">
					<div class="peers ai-c fxw-nw">
						<div class="peer peer-greed">
							<a class="sidebar-link td-n" href="<?php echo base_url()?>dashboard"  class="td-n">
								<div class="peers ai-c fxw-nw">
									<div class="peer">
										<div class="logo">
											<img src="<?php echo base_url();?>front-end/images/logo.png" alt="">
										</div>
									</div>
									<div class="peer peer-greed">
										<h5 class="lh-1 mB-0 logo-text"  style="font-family:'Montserrat', sans-serif;font-weight: 700;">Admin Panel</h5>
									</div>
								</div>
							</a>
						</div>
						<div class="peer">
							<div class="mobile-toggle sidebar-toggle">
								<a href="#" class="td-n">
									<i class="ti-arrow-circle-left"></i>
								</a>
							</div>
						</div>
					</div>
				</div>
				<ul class="sidebar-menu scrollable pos-r">
					<li class="nav-item mT-30 active">
						<a class="sidebar-link" href="<?php echo base_url()?>dashboard" >
							<span class="icon-holder">
								<i class="c-blue-500 ti-home"></i>
							</span>
							<span class="title" >Dashboard</span>
						</a>
					</li>


					<li class="nav-item dropdown">
						<a class="dropdown-toggle" href="javascript:void(0);">
							<span class="icon-holder">
								<i class="c-teal-500 fab fa-accessible-icon"></i>
							</span>
							<span class="title">Booking Service</span>
							<span class="arrow">
								<i class="ti-angle-right"></i>
							</span>
						</a>
						<ul class="dropdown-menu">
							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span >Vehicles</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">

									<li>
										<a class=""  href="<?php echo base_url()?>show-car-list">
											<span class="icon-holder">
												<i class="fa fa-car"></i>
											</span>
											<span class="title">Car</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-motorcycle"></i>
											</span>
											<span class="title">Bike</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-bus"></i>
											</span>
											<span class="title">Microbus</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-ambulance"></i>
											</span>
											<span class="title">Ambulance</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fas fa-helicopter"></i>
											</span>
											<span class="title">Helicopter</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/cng_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/cng-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/cng_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											
											<span class="title">CNG</span>
										</a>
									</li>
									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/rick_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/rick-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/rick_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											<span class="title">Rickshaw</span>
										</a>
									</li>
								</ul>
							</li>

							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span>All Rides</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">

									<li>
										<a class="dropdown-toggle"  href="<?php echo base_url()?>show-car-ride">
											<span class="icon-holder">
												<i class="fa fa-car"></i>
											</span>
											<span class="title">Car</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-motorcycle"></i>
											</span>
											<span class="title">Bike</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-bus"></i>
											</span>
											<span class="title">Microbus</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-ambulance"></i>
											</span>
											<span class="title">Ambulance</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fas fa-helicopter"></i>
											</span>
											<span class="title">Helicopter</span>
										</a>
									</li>


									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/cng_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/cng-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/cng_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											
											<span class="title">CNG</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/rick_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/rick-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/rick_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											<span class="title">Rickshaw</span>
										</a>
									</li>


								</ul>
							</li>

							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span>Drivers</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-car-drivers">
											<span class="icon-holder">
												<i class="fa fa-car"></i>
											</span>
											<span class="title">Car</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-motorcycle"></i>
											</span>
											<span class="title">Bike</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-bus"></i>
											</span>
											<span class="title">Microbus</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-ambulance"></i>
											</span>
											<span class="title">Ambulance</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fas fa-helicopter"></i>
											</span>
											<span class="title">Helicopter</span>
										</a>
									</li>


									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/cng_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/cng-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/cng_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											
											<span class="title">CNG</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/rick_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/rick-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/rick_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											<span class="title">Rickshaw</span>
										</a>
									</li>
								</ul>
							</li>	

							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span>Passengers</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-car-passengers">
											<span class="icon-holder">
												<i class="fa fa-car"></i>
											</span>
											<span class="title">Car</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-motorcycle"></i>
											</span>
											<span class="title">Bike</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-bus"></i>
											</span>
											<span class="title">Microbus</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fa fa-ambulance"></i>
											</span>
											<span class="title">Ambulance</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<i class="fas fa-helicopter"></i>
											</span>
											<span class="title">Helicopter</span>
										</a>
									</li>


									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/cng_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/cng-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/cng_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											
											<span class="title">CNG</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle" href="javascript:void(0);">
											<span class="icon-holder">
												<img src = "<?php echo base_url();?>front-end/icons/rick_GREY-01.png" onmouseover = "src = '<?php echo base_url();?>front-end/icons/rick-01.png' " onmouseout = "src = '<?php echo base_url();?>front-end/icons/rick_GREY-01.png' " 
												alt = "" style ="width: 10%;
												height: auto; " /> 

											</span>
											<span class="title">Rickshaw</span>
										</a>
									</li>
								</ul>
							</li>
						</ul>
					</li>

					<li class="nav-item dropdown">
						<a class="dropdown-toggle" href="javascript:void(0);">
							<span class="icon-holder">
								<i class="c-brown-500 ti-email"></i>
							</span>
							<span class="title">Parcel Service</span>
							<span class="arrow">
								<i class="ti-angle-right"></i>
							</span>
						</a>
						<ul class="dropdown-menu">
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-all-delivers">All delivers</a>
							</li>
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-vendors">Vendors</a>
							</li>
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-customers">Customers</a>
							</li>
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-delivery-man">Delivery Man</a>
							</li>

						</ul>
					</li>



					<li class="nav-item dropdown">
						<a class="dropdown-toggle" href="javascript:void(0);">
							<span class="icon-holder">
								<i class="c-orange-500 fas fa-hamburger"></i>
							</span>
							<span class="title">Food</span>
							<span class="arrow">
								<i class="ti-angle-right"></i>
							</span>
						</a>
						<ul class="dropdown-menu">
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-food-sales">Sales</a>
							</li>

							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-food-restaurant">Restaurant</a>
							</li>
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-food-foodlist">Foods</a>
							</li>
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-food-customer">Customers</a>
							</li>
							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-food-delivery-man">Delivery man</a>
							</li>

						</ul>
					</li>

					<li class="nav-item dropdown">
						<a class="dropdown-toggle" href="javascript:void(0);">
							<span class="icon-holder">
								<i class="c-blue-500 ti-ticket"></i>
							</span>
							<span class="title">Ticketing</span>
							<span class="arrow">
								<i class="ti-angle-right"></i>
							</span>
						</a>

						

						<ul class="dropdown-menu">

							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-ticket-booking-list">Bookings</a>
							</li>

							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span >Travel Vendors</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-bus-vendor-list">
											<span class="icon-holder">
												<i class="fa fa-bus"></i>
											</span>
											<span class="title">Bus</span>
										</a>
									</li>

									<li>
										<a class=""  href="<?php echo base_url()?>show-train-vendor-list">
											<span class="icon-holder">
												<i class="fa fa-train"></i>
											</span>
											<span class="title">Train</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-launch-vendor-list">
											<span class="icon-holder">
												<i class="fa fa-ship"></i>
											</span>
											<span class="title">Launch</span>
										</a>
									</li>


									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-train-vendor-list;">
											<span class="icon-holder">
												<i class="fa fa-plane"></i>
											</span>
											<span class="title">Airlines</span>
										</a>
									</li>		
								</ul>
							</li>

							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span>Passengers</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-bus-passenger-list">
											<span class="icon-holder">
												<i class="fa fa-bus"></i>
											</span>
											<span class="title">Bus</span>
										</a>
									</li>

									<li>
										<a class=""  href="<?php echo base_url()?>show-train-passenger-list">
											<span class="icon-holder">
												<i class="fa fa-train"></i>
											</span>
											<span class="title">Train</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-launch-passenger-list">
											<span class="icon-holder">
												<i class="fa fa-ship"></i>
											</span>
											<span class="title">Launch</span>
										</a>
									</li>


									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-airlines-passenger-list">
											<span class="icon-holder">
												<i class="fa fa-plane"></i>
											</span>
											<span class="title">Airlines</span>
										</a>
									</li>		
								</ul>
							</li>
						</ul>
					</li>

					<li class="nav-item dropdown">
						<a class="dropdown-toggle" href="javascript:void(0);">
							<span class="icon-holder">
								<i class="c-orange-500 ti-money"></i>
							</span>
							<span class="title">Donation</span>
							<span class="arrow">
								<i class="ti-angle-right"></i>
							</span>
						</a>

						<ul class="dropdown-menu">

							<li>
								<a class="sidebar-link" href="<?php echo base_url()?>show-donation-transaction-list">Transactions</a>
							</li>

							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span >Donor</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-old-donor-list">
											<span class="icon-holder">
												<i class="fas fa-hand-holding-heart"></i>
											</span>
											<span class="title">Old Donation</span>
										</a>
									</li>

									<li>
										<a class=""  href="<?php echo base_url()?>show-orphanage-donor-list">
											<span class="icon-holder">
												<i class="fas fa-hand-holding-heart"></i>
											</span>
											<span class="title">Orphanage</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-mosque-donor-list">
											<span class="icon-holder">
												<i class="fas fa-hand-holding-heart"></i>
											</span>
											<span class="title">Mosque</span>
										</a>
									</li>


									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-madrasha-donor-list">
											<span class="icon-holder">
												<i class="fas fa-hand-holding-heart"></i>
											</span>
											<span class="title">Madrasha</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-zaqat-donor-list">
											<span class="icon-holder">
												<i class="fas fa-hand-holding-heart"></i>
											</span>
											<span class="title">Zaqat & Fetra</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-quarbani-donor-list">
											<span class="icon-holder">
												<i class="fas fa-hand-holding-heart"></i>
											</span>
											<span class="title">Quarbani</span>
										</a>
									</li>		
								</ul>
							</li>

							<li class="nav-item dropdown">
								<a href="javascript:void(0);">
									<span>Reciepent</span>
									<span class="arrow">
										<i class="ti-angle-right"></i>
									</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-old-
											recipient-list">
											<span class="icon-holder">
												<i class="fas fa-donate"></i>
											</span>
											<span class="title">Old Donation</span>
										</a>
									</li>

									<li>
										<a class="dropdown-toggle"  href="<?php echo base_url()?>show-orphanage-recipient-list">
											<span class="icon-holder">
												<i class="fas fa-donate"></i>
											</span>
											<span class="title">Orphanage</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-mosque-recipient-list">
											<span class="icon-holder">
												<i class="fas fa-donate"></i>
											</span>
											<span class="title">Mosque</span>
										</a>
									</li>


									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-madrasha-recipient-list">
											<span class="icon-holder">
												<i class="fas fa-donate"></i>
											</span>
											<span class="title">Madrasha</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-zaqat-recipient-list">
											<span class="icon-holder">
												<i class="fas fa-donate"></i>
											</span>
											<span class="title">Zaqat & Fetra</span>
										</a>
									</li>	

									<li>
										<a class="dropdown-toggle" href="<?php echo base_url()?>show-quarbani-recipient-list">
											<span class="icon-holder">
												<i class="fas fa-donate"></i>
											</span>
											<span class="title">Quarbani</span>
										</a>
									</li>		
								</ul>
							</li>
						</ul>
					</li>

					<li class="nav-item dropdown">
						<a class="dropdown-toggle" href="javascript:void(0);">
							<span class="icon-holder">
								<i class="c-orange-500 ti-heart"></i>
							</span>
							<span class="title">Health & Fitness</span>
							<span class="arrow">
								<i class="ti-angle-right"></i>
							</span>
						</a>
						<ul class="dropdown-menu">
							<li>
								<a class="sidebar-link" href="basic-table.html">Step Counter</a>
							</li>
							<li>
								<a class="sidebar-link" href="datatable.html">Medicine Reminder</a>
							</li>
							<li>
								<a class="sidebar-link" href="datatable.html">Medicine Order</a>
							</li>
							<li>
								<a class="sidebar-link" href="datatable.html">Doctor Appointment</a>
							</li>

						</ul>
					</li>
					

					<li class="nav-item">
						<a class="sidebar-link" href="email.html">
							<span class="icon-holder">
								<i class="c-brown-500 ti-signal"></i>
							</span>
							<span class="title">Safety & Security</span>
						</a>
					</li>


					<li class="nav-item">
						<a class="sidebar-link" href="compose.html">
							<span class="icon-holder">
								<i class="c-blue-500 ti-wallet"></i>
							</span>
							<span class="title">Islamic Wallet</span>
						</a>
					</li>
				</div>
			</div>


			<div class="page-container">
				<div class="header navbar">
					<div class="header-container">
						<ul class="nav-left">
							<li>
								<a id="sidebar-toggle" class="sidebar-toggle" href="javascript:void(0);">
									<i class="ti-menu"></i>
								</a>
							</li>
							<li class="search-box">
								<a class="search-toggle no-pdd-right" href="javascript:void(0);">
									<i class="search-icon ti-search pdd-right-10"></i>
									<i class="search-icon-close ti-close pdd-right-10"></i>
								</a>
							</li>
							<li class="search-input">
								<input class="form-control" type="text" placeholder="Search...">
							</li>
						</ul>
						<ul class="nav-right">
							<li class="notifications dropdown">
								<span class="counter bgc-red">3</span>
								<a href="#" class="dropdown-toggle no-after" data-toggle="dropdown">
									<i class="ti-bell"></i>
								</a>
								<ul class="dropdown-menu">
									<li class="pX-20 pY-15 bdB">
										<i class="ti-bell pR-10"></i>
										<span class="fsz-sm fw-600 c-grey-900">Notifications</span>
									</li>
									<li>
										<ul class="ovY-a pos-r scrollable lis-n p-0 m-0 fsz-sm">
											<li>
												<a href="#" class="peers fxw-nw td-n p-20 bdB c-grey-800 cH-blue bgcH-grey-100">
													<div class="peer mR-15">
														<img class="w-3r bdrs-50p" src="../../../randomuser.me/api/portraits/men/1.jpg" alt="">
													</div>
													<div class="peer peer-greed">
														<span>

															<span class="fw-500">John Doe</span>
															<span class="c-grey-600">liked your 
																<span class="text-dark">post</span>
															</span>
														</span>
														<p class="m-0">
															<small class="fsz-xs">5 mins ago</small>
														</p>
													</div>
												</a>
											</li>
											<li>
												<a href="#" class="peers fxw-nw td-n p-20 bdB c-grey-800 cH-blue bgcH-grey-100">
													<div class="peer mR-15">
														<img class="w-3r bdrs-50p" src="../../../randomuser.me/api/portraits/men/2.jpg" alt="">
													</div>
													<div class="peer peer-greed">
														<span>
															<span class="fw-500">Moo Doe</span>
															<span class="c-grey-600">liked your 
																<span class="text-dark">cover image</span>
															</span>
														</span>
														<p class="m-0">
															<small class="fsz-xs">7 mins ago</small>
														</p>
													</div>
												</a>
											</li>
											<li>
												<a href="#" class="peers fxw-nw td-n p-20 bdB c-grey-800 cH-blue bgcH-grey-100">
													<div class="peer mR-15">
														<img class="w-3r bdrs-50p" src="../../../randomuser.me/api/portraits/men/3.jpg" alt="">
													</div>
													<div class="peer peer-greed">
														<span>
															<span class="fw-500">Lee Doe</span>
															<span class="c-grey-600">commented on your 
																<span class="text-dark">video</span>
															</span>
														</span>
														<p class="m-0">
															<small class="fsz-xs">10 mins ago</small>
														</p>
													</div>
												</a>
											</li>
										</ul>
									</li>
									<li class="pX-20 pY-15 ta-c bdT">
										<span>
											<a href="#" class="c-grey-600 cH-blue fsz-sm td-n">View All Notifications 
												<i class="ti-angle-right fsz-xs mL-10"></i>
											</a>
										</span>
									</li>
								</ul>
							</li>
							<li class="notifications dropdown">
								<span class="counter bgc-blue">3</span>
								<a href="#" class="dropdown-toggle no-after" data-toggle="dropdown">
									<i class="ti-email"></i>
								</a>
								<ul class="dropdown-menu">
									<li class="pX-20 pY-15 bdB">
										<i class="ti-email pR-10"></i>
										<span class="fsz-sm fw-600 c-grey-900">Emails</span>
									</li>
									<li>
										<ul class="ovY-a pos-r scrollable lis-n p-0 m-0 fsz-sm">
											<li>
												<a href="#" class="peers fxw-nw td-n p-20 bdB c-grey-800 cH-blue bgcH-grey-100">
													<div class="peer mR-15">
														<img class="w-3r bdrs-50p" src="../../../randomuser.me/api/portraits/men/1.jpg" alt="">
													</div>
													<div class="peer peer-greed">
														<div>
															<div class="peers jc-sb fxw-nw mB-5">
																<div class="peer">

																	<p class="fw-500 mB-0">John Doe</p>
																</div>
																<div class="peer">
																	<small class="fsz-xs">5 mins ago</small>
																</div>
															</div>
															<span class="c-grey-600 fsz-sm">Want to create your own customized data generator for your app...</span>
														</div>
													</div>
												</a>
											</li>
											<li>
												<a href="#" class="peers fxw-nw td-n p-20 bdB c-grey-800 cH-blue bgcH-grey-100">
													<div class="peer mR-15">
														<img class="w-3r bdrs-50p" src="../../../randomuser.me/api/portraits/men/2.jpg" alt="">
													</div>
													<div class="peer peer-greed">
														<div>
															<div class="peers jc-sb fxw-nw mB-5">
																<div class="peer">
																	<p class="fw-500 mB-0">Moo Doe</p>
																</div>
																<div class="peer">
																	<small class="fsz-xs">15 mins ago</small>
																</div>
															</div>
															<span class="c-grey-600 fsz-sm">Want to create your own customized data generator for your app...</span>
														</div>
													</div>
												</a>
											</li>
											<li>
												<a href="#" class="peers fxw-nw td-n p-20 bdB c-grey-800 cH-blue bgcH-grey-100">
													<div class="peer mR-15">
														<img class="w-3r bdrs-50p" src="../../../randomuser.me/api/portraits/men/3.jpg" alt="">
													</div>
													<div class="peer peer-greed">
														<div>
															<div class="peers jc-sb fxw-nw mB-5">
																<div class="peer">
																	<p class="fw-500 mB-0">Lee Doe</p>
																</div>
																<div class="peer">
																	<small class="fsz-xs">25 mins ago</small>
																</div>
															</div>
															<span class="c-grey-600 fsz-sm">Want to create your own customized data generator for your app...</span>
														</div>
													</div>
												</a>
											</li>
										</ul>
									</li>
									<li class="pX-20 pY-15 ta-c bdT">
										<span>
											<a href="#" class="c-grey-600 cH-blue fsz-sm td-n">View All Email 
												<i class="fs-xs ti-angle-right mL-10"></i>
											</a>
										</span>
									</li>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle no-after peers fxw-nw ai-c lh-1" data-toggle="dropdown">
									<div class="peer mR-10">
										<img class="w-2r bdrs-50p" src="front-end/images/admin.jpg" alt="">
									</div>
									<div class="peer">
										<span class="fsz-sm c-black-900"><strong><?php echo $this->session->userdata('admin_name'); ?></strong></span>
									</div>
								</a>
								<ul class="dropdown-menu fsz-sm">
									<li>
										<a href="#" class="d-b td-n pY-5 bgcH-grey-100 c-grey-700">
											<i class="ti-settings mR-10"></i>
											<span>Setting</span>
										</a>
									</li>
									<li>
										<a href="#" class="d-b td-n pY-5 bgcH-grey-100 c-grey-700">
											<i class="ti-user mR-10"></i>
											<span>Profile</span>
										</a>
									</li>
									<li>
										<a href="#" class="d-b td-n pY-5 bgcH-grey-100 c-grey-700">
											<i class="ti-email mR-10"></i>
											<span>Messages</span>
										</a>
									</li>
									<li role="separator" class="divider"></li>
									<li>
										<a href="<?php base_url();?>logout" class="d-b td-n pY-5 bgcH-grey-100 c-grey-700">
											<i class="ti-power-off mR-10"></i>
											<span>Logout</span>
										</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
				</div>

				<main class="main-content bgc-grey-100">
					<?php echo $admin_main_content; ?>	
				</main>
				<footer class="bdT ta-c p-30 lh-0 fsz-sm c-grey-600">
					<span>Copyright © 2021 Edited by 
						<a href="" target="_blank" title="Colorlib">Ariful Hoque</a>. All rights reserved.
					</span>
					<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
					<script>
						window.dataLayer = window.dataLayer || [];
						function gtag(){dataLayer.push(arguments);}
						gtag('js', new Date());

						gtag('config', 'UA-23581568-13');
					</script>
				</footer>
			</div>
		</div>
		<script
		src="https://code.jquery.com/jquery-3.5.1.min.js"
		integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
		crossorigin="anonymous"></script>
		<script type="text/javascript" src="<?php echo base_url();?>/front-end/js/vendor.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>/front-end/js/bundle.js"></script>

		<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.23/datatables.min.js"></script>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.js"></script>
		<style>

			.dataTables_wrapper {
				font-family:'Montserrat', sans-serif;font-weight: 600;

			}
		</style>
		<script>
			$(document).ready(function() {
				$('.table1').DataTable({"scrollX": true});
			} );
		</script>

		<script type="text/javascript">window.addEventListener('load', () => {
			const loader = document.getElementById('loader');
			setTimeout(() => {
				loader.classList.add('fadeOut');
			}, 300);
		});
	</script>
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>
<!-- Mirrored from colorlib.com/polygon/adminator/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 Feb 2021 10:32:23 GMT -->
</html>
