
<link href="<?php echo base_url();?>front-end/css/style.css" rel="stylesheet"> 
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;800&display=swap" rel="stylesheet">
<div class="row page-titles">
	<div class="col-md-5 align-self-center">
		<h3 class="text-themecolor" style="font-family:'Montserrat', sans-serif ;">Bus vendors</h3>

	</div>
	<div class="col-md-7 align-self-center">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
			<li class="breadcrumb-item">Ticketing</li>
			<li class="breadcrumb-item">Travel vendors</li>
			<li class="breadcrumb-item active">Bus</li>
		</ol>
	</div>
	<div>
		<!-- <button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button> -->
	</div>
</div>

<div class="container-fluid">
	<!-- ============================================================== -->
	<!-- Start Page Content -->
	<!-- ============================================================== -->
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<h4 class="card-title" >Bus Vendor list</h4>
					<!-- <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6> -->
					<button type="button" class="btn btn-dark btn-sm" data-toggle="modal" data-target="#add-type-vehicule" style="font-family:'Montserrat', sans-serif ; margin-bottom: 10px;"><i class="fa fa-plus m-r-10"></i>Add</button>
					<div id="add-type-vehicule" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg">
							<div class="modal-content bg-gris">
								<div class="modal-header">
									<h4 class="modal-title" id="myModalLabel">Add a Bus Vendor</h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<form class="form-horizontal " action="<?php base_url();?>save-bus-travel-vendor" method="post" enctype="multipart/form-data">
									<div class="modal-body">
										<div class="form-group">
											<div class="row">
												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Name of the Agency </label>
														<input type="text" class="form-control " placeholder="" name="agency_name" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Address</label>
														<input type="text" class="form-control " placeholder="" name="address" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>
												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Tin Number</label>
														<input type="number" class="form-control " placeholder="" name="tin_number" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div> 

												

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Represenative/Owner </label>
														<input type="text" class="form-control " placeholder="" name="owner_name" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Route Number</label>
														<input type="number" class="form-control " placeholder="" name="route_number" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>


												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">From</label>
														<input type="text" class="form-control " placeholder="" name="from" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div> 

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">To</label>
														<input type="text" class="form-control " placeholder="" name="to" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div> 

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Via</label>
														<input type="text" class="form-control " placeholder="" name="via" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Payment method</label>
														<input type="text" class="form-control " placeholder="" name="payment_method" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Phone no.</label>
														<input type="number" class="form-control " placeholder="" name="contact_number">
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div> 


											</div>
										</div>
									</div>
									<div class="modal-footer">
										<button type="submit" class="btn btn-dark waves-effect" style="font-family:'Montserrat', sans-serif ;">Save</button>
										<button type="button" class="btn btn-default waves-effect" data-dismiss="modal" style="font-family:'Montserrat', sans-serif ;">Cancel</button>
									</div>
								</form>
							</div>
							<!-- /.modal-content -->
						</div>
						<!-- /.modal-dialog -->
					</div>

					<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#add-type-bus" style="font-family:'Montserrat', sans-serif ; margin-bottom: 10px;"><i class="fa fa-plus m-r-10"></i>Add bus</button>
					<div id="add-type-bus" class="modal fade in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg">
							<div class="modal-content bg-gris">
								<div class="modal-header">
									<h4 class="" id="">Add a Bus </h4>
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
								</div>
								<form class="form-horizontal " action="<?php base_url();?>save-ticketing-bus" method="post" enctype="multipart/form-data">
									<div class="modal-body">
										<div class="form-group">
											<div class="row">

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Tin Number</label>
														<input type="number" class="form-control " placeholder="" name="owner_tin_id" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>

												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Bus number</label>
														<input type="text" class="form-control " placeholder="" name="bus_number" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div>
												<div class="col-md-12 m-b-0">
													<div class="form-group mb-3">
														<label class="mr-sm-2" for="designation" style="font-family:'Montserrat', sans-serif ;">Chesis Number</label>
														<input type="number" class="form-control " placeholder="" name="chesis_number" > 
														<div class="invalid-feedback">
															Désolé, entrez l'intitulé de la catégorie de devis
														</div>
													</div>
												</div> 
											</div>
										</div>
									</div>
									<div class="modal-footer">
										<button type="submit" class="btn btn-dark waves-effect" style="font-family:'Montserrat', sans-serif ;">Save</button>
										<button type="button" class="btn btn-default waves-effect" data-dismiss="modal" style="font-family:'Montserrat', sans-serif ;">Cancel</button>
									</div>
								</form>
							</div>
							<!-- /.modal-content -->
						</div>
						<!-- /.modal-dialog -->
					</div>

					<?php
					$message = $this->session->userdata('message');

					if ($message) {
						?>
						<div class="alert alert-success" style="font-family:'Montserrat', sans-serif;font-weight: 700;">
							<?php echo $message ?> 
						</div>
						<?php
						$this->session->unset_userdata('message');
					}
					?> 

					<div class="table-responsive m-t-10">
						<table id="" class="display nowrap table table-hover table-striped table-bordered table1" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th>N°</th>
									<th width="10%">Agency Name</th>
									<th>Address</th>
									<th>Tin</th>  
									<th>Representative</th>
									<th>Route number</th>
									<th>From</th>
									<th>To</th>
									<th>via</th>
									<th>Payment method</th>
									<th>Bus no</th>
									<th>Chesis no</th>
									<th>Phone no</th>
									
								</tr>
							</thead>
							<tbody>
								<?php foreach($all_bus_vendors as $vendor):?>
									<tr>
										<td><?php echo  $vendor->agency_id  ?></td>
										<td><?php echo  $vendor->agency_name ?></td>
										<td><?php echo  $vendor->agency_address ?></td>
										<td><?php echo  $vendor->tin_id  ?></td>
										<td><?php echo  $vendor->owner_name ?></td>
										<td><?php echo  $vendor->route_number ?></td>
										<td><?php echo  $vendor->bus_from ?></td>
										<td><?php echo  $vendor->bus_to ?></td>
										<td><?php echo  $vendor->bus_via ?></td>
										<td><?php echo  $vendor->payment_method ?></td>
										<td><?php echo  $vendor->phone_no ?></td>
										<td><?php echo  $vendor->bus_number ?></td>
										<td><?php echo  $vendor->chesis_number ?></td>
									</tr>
								<?php endforeach; ?> 

							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

