
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ticketing_model extends CI_Model
{
	public function get_booking_list(){
		$this->db->SELECT('*');
		$this->db->FROM('ticketing_booking');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_bus_passenger_list(){
		$this->db->SELECT('*');
		$this->db->FROM('ticketing_bus_passengers');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_train_passenger_list(){
		$this->db->SELECT('*');
		$this->db->FROM('ticketing_train_passengers');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_launch_passenger_list(){
		$this->db->SELECT('*');
		$this->db->FROM('ticketing_launch_passengers');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_airlines_passenger_list(){
		$this->db->SELECT('*');
		$this->db->FROM('ticketing_airlines_passengers');
		$query_result = $this->db->get();
		return $query_result->result();
	}	
	public function get_bus_vendor_list(){
		$this->db->SELECT('*');
		$this->db->FROM('ticketing_bus_vendor');
		$this->db->JOIN('ticketing_bus_list','ticketing_bus_list. owner_tin_id = ticketing_bus_vendor.tin_id' );
		$query_result = $this->db->get();
		return $query_result->result();
	}	


	public function save_bus_vendor_info(){
		$data=array();
		$data['agency_name'] = $this->input->post('agency_name',true);
		$data['agency_address'] = $this->input->post('address',true);
		$data['tin_id'] = $this->input->post('tin_number',true);
		$data['owner_name'] = $this->input->post('owner_name',true);
		$data['route_number'] = $this->input->post('route_number',true);	
		$data['bus_from'] = $this->input->post('from',true);	
		$data['bus_to'] = $this->input->post('to',true);	
		$data['bus_via'] = $this->input->post('via',true);	
		$data['payment_method'] = $this->input->post('payment_method',true);	
		$data['phone_no'] = $this->input->post('contact_number',true);	
		$this->db->insert('ticketing_bus_vendor',$data);
	}
	public function save_bus_info(){
		$data=array();
		$data['owner_tin_id'] = $this->input->post('owner_tin_id',true);
		$data['bus_number'] = $this->input->post('bus_number',true);
		$data['chesis_number'] = $this->input->post('chesis_number',true);	
		$this->db->insert('ticketing_bus_list',$data);
	}
}
