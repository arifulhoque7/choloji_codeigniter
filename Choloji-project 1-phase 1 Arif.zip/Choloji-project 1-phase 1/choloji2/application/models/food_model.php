
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Food_model extends CI_Model
{


	public function get_food_customer(){
		$this->db->SELECT('*');
		$this->db->FROM('food_customer');
		$query_result = $this->db->get();
		return $query_result->result();
	}

	public function get_food_foodlist(){
		$this->db->SELECT('*');
		$this->db->FROM('food_list');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_food_sale(){
		$this->db->SELECT('*');
		$this->db->FROM('food_sales');
		$query_result = $this->db->get();
		return $query_result->result();
	}

	public function get_food_restaurant(){
		$this->db->SELECT('*');
		$this->db->FROM('food_restaurant');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_food_deliveryman(){
		$this->db->SELECT('*');
		$this->db->FROM('food_deliveryman');
		$query_result = $this->db->get();
		return $query_result->result();
	}

	public function save_food_driveryman_info(){
		$data=array();
		$data['deliveryman_name'] = $this->input->post('deliveryman_name',true);
		$data['deliveryman_phone'] = $this->input->post('deliveryman_phone',true);
		$data['deliveryman_nid'] = $this->input->post('deliveryman_nid',true);
		$data['created_date'] = date("Y-m-d");

		$sdata =array();

		$config['upload_path']          = './food_deliveryman_image/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['encrypt_name']        = true;
		$config['max_size']             = 100000000000;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('deliveryman_photo'))
		{
			$error =  $this->upload->display_errors();
                	// print_r($this->upload->display_errors());
		}
		else
		{
			$sdata =  $this->upload->data();

			$data['deliveryman_photo'] = $config['upload_path'].$sdata['file_name'];
                			// print_r($this->upload->data());
		}
		$this->db->insert('food_deliveryman',$data);
	}
	public function save_food_restaurant_info(){
		$data=array();
		$data['restaurant_name'] = $this->input->post('restaurant_name',true);
		$data['restaurant_address'] = $this->input->post('restaurant_address',true);
		$data['restaurant_map_address'] = $this->input->post('restaurant_map_address',true);
		$data['restaurant_coupons'] = $this->input->post('restaurant_coupons',true);
		$data['restaurant_delivery_fee'] = $this->input->post('restaurant_delivery_fee',true);
		$data['restaurant_tax'] = $this->input->post('restaurant_tax',true);
		$data['restaurant_tin'] = $this->input->post('restaurant_tin',true);
		$this->db->insert('food_restaurant',$data);
	}
}

