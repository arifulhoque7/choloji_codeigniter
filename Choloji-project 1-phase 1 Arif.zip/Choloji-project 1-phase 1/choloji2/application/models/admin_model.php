<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

	public function admin_model_info($username, $password)
	{
		$this->db->select('*');
		$this->db->from('tbl_admin');
		$this->db->where('username' , $username);
		$this->db->where('password', $password);
		$query_result = $this->db->get();
		$result = $query_result->row();
		return $result;

	}

	public function all_bike_info(){
		$this->db->select('*');
		$this->db->from('bike_db');
		$query_result = $this->db->get();
		$bike_info = $query_result->result();
		return $bike_info;
	}

	public function delete_bike_by($id){
		$this->db->where('id',$id);
		$this->db->delete('bike_db');
	}
}
