
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Car_model extends CI_Model
{


	public function get_cars(){
		$this->db->SELECT('*');
		$this->db->FROM('cars');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	
	public function save_car_info(){
		$data=array();
		$data['car_name'] = $this->input->post('car_name',true);
		$data['car_cost'] = $this->input->post('car_cost',true);
		$data['car_class'] = $this->input->post('car_class',true);
		$data['car_booking_type'] = $this->input->post('car_booking_type',true);
		$data['car_service_cost'] = $this->input->post('car_service_cost',true);
		$data['created'] = date("Y-m-d");

		$sdata =array();

		 $config['upload_path']          = './car_image/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['encrypt_name']        = true;
                $config['max_size']             = 10000000;
                // $config['max_width']            = 1024;
                // $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('car_image'))
                {
                        $error =  $this->upload->display_errors();
                	// print_r($this->upload->display_errors());
                }
                else
                {
                        $sdata =  $this->upload->data();

                        $data['car_image'] = $config['upload_path'].$sdata['file_name'];
                			// print_r($this->upload->data());

                }

		$this->db->insert('cars',$data);
	}

	public function get_rides(){
		$this->db->SELECT('*');
		$this->db->FROM('car_riders');
		$query_result = $this->db->get();
		return $query_result->result();
	}


	public function get_drivers(){
		$this->db->SELECT('*');
		$this->db->FROM('car_driver');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	
	public function save_driver_info(){
		$data=array();
		$data['driver_name'] = $this->input->post('driver_name',true);
		$data['driver_phone'] = $this->input->post('driver_phone',true);
		$data['driver_nid'] = $this->input->post('driver_nid',true);
		$data['created_date'] = date("Y-m-d");

		$sdata =array();

		 $config['upload_path']          = './car_driver_image/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['encrypt_name']        = true;
                $config['max_size']             = 100000000000;
                // $config['max_width']            = 1024;
                // $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('driver_photo'))
                {
                        $error =  $this->upload->display_errors();
                	// print_r($this->upload->display_errors());
                }
                else
                {
                        $sdata =  $this->upload->data();

                        $data['driver_photo'] = $config['upload_path'].$sdata['file_name'];
                			// print_r($this->upload->data());

                }

		$this->db->insert('car_driver',$data);
	}
	public function delete_car_info($car_id){
		$this->db->WHERE('car_id',$car_id);
		$this->db->DELETE('cars');
	}
	public function delete_car_driver_info($car_driver_id){
		$this->db->WHERE('driver_id',$car_driver_id);
		$this->db->DELETE('car_driver');
	}
	public function get_passengers(){
		$this->db->SELECT('*');
		$this->db->FROM('car_passsengers');
		$query_result = $this->db->get();
		return $query_result->result();
	}
}
