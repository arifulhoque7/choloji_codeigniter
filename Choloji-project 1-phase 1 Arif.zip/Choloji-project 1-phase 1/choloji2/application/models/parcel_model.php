
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parcel_model extends CI_Model
{
	public function get_delivers(){
		$this->db->SELECT('*');
		$this->db->FROM('parcel_deliver');
		$query_result = $this->db->get();
		return $query_result->result();
	}

	public function get_vendors(){
		$this->db->SELECT('*');
		$this->db->FROM('parcel_vendor');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_customers(){
		$this->db->SELECT('*');
		$this->db->FROM('parcel_customer');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_deliveryman(){
		$this->db->SELECT('*');
		$this->db->FROM('parcel_deliveryman');
		$query_result = $this->db->get();
		return $query_result->result();
	}

	public function save_vendor_info(){
		$data=array();
		$data['vendor_name'] = $this->input->post('company_name',true);
		$data['vendor_address'] = $this->input->post('address',true);
		$data['vendor_contact'] = $this->input->post('contact_number',true);
		$data['vendor_license'] = $this->input->post('license_no',true);
		$data['vendor_year'] = $this->input->post('number_of_year',true);
		$data['vendor_type'] = $this->input->post('vendor_type',true);

		$this->db->insert('parcel_vendor',$data);
	}

	public function save_driveryman_info(){
		$data=array();
		$data['deliveryman_name'] = $this->input->post('deliveryman_name',true);
		$data['deliveryman_phone'] = $this->input->post('deliveryman_phone',true);
		$data['deliveryman_nid'] = $this->input->post('deliveryman_nid',true);
		$data['created_date'] = date("Y-m-d");

		$sdata =array();

		$config['upload_path']          = './parcel_deliveryman_image/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['encrypt_name']        = true;
		$config['max_size']             = 100000000000;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('deliveryman_photo'))
		{
			$error =  $this->upload->display_errors();
                	// print_r($this->upload->display_errors());
		}
		else
		{
			$sdata =  $this->upload->data();

			$data['deliveryman_photo'] = $config['upload_path'].$sdata['file_name'];
                			// print_r($this->upload->data());

		}

		$this->db->insert('parcel_deliveryman',$data);
	}
}
