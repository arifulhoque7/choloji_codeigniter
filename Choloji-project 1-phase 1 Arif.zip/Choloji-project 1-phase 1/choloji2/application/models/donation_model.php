
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Donation_model extends CI_Model
{
	public function get_donation_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_transaction');
		$query_result = $this->db->get();
		return $query_result->result();
	}

	public function get_old_donor_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_donor_old');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_orphanage_donor_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_donor_orphanage');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_mosque_donor_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_donor_mosque');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_madrasha_donor_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_donor_madrasha');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_zaqat_donor_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_donor_zaqat');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_quarbani_donor_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_donor_quarbani');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_old_recipient_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_recipient_old');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_orphanage_recipient_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_recipient_orphanage');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_mosque_recipient_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_recipient_mosque');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_madrasha_recipient_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_recipient_madrasha');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_zaqat_recipient_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_recipient_zaqat');
		$query_result = $this->db->get();
		return $query_result->result();
	}
	public function get_quarbani_recipient_details(){
		$this->db->SELECT('*');
		$this->db->FROM('donation_recipient_quarbani');
		$query_result = $this->db->get();
		return $query_result->result();
	}
}
