<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['admin-login'] = 'admin/admin_login';
$route['logout'] = 'admin/logout';



$route['show-car-customer'] = 'car/show_car_customer';
$route['show-car-driver'] = 'car/show_car_driver';
$route['show-car-notification'] = 'car/show_car_notification';

$route['show-car-vehicle-type'] = 'car/show_vehicle_type';
$route['show-car-user-catagory'] = 'car/show_car_user_catagory';


$route['show-car-all'] = 'car/show_car_all';
$route['show-car-new'] = 'car/show_car_new';
$route['show-car-confirmed'] = 'car/show_car_confirmed';
$route['show-car-onride'] = 'car/show_car_onride';
$route['show-car-completed'] = 'car/show_car_completed';
$route['show-car-canceled'] = 'car/show_car_canceled';

//new edit

$route['show-car-list'] = 'car_booking/show_car_list';
$route['show-car-ride'] = 'car_booking/show_car_ride';
$route['show-car-drivers'] = 'car_booking/show_car_drivers';
$route['show-car-passengers'] = 'car_booking/show_car_passengers';

$route['save-car'] = 'car_booking/save_car';
$route['save-driver'] = 'car_booking/save_driver';

$route['delete-car/(.+)'] = 'car_booking/delete_car/$1';
$route['delete-car-driver/(.+)'] = 'car_booking/delete_car_driver/$1';
//car done



//parcel service

$route['show-all-delivers'] = 'parcel_service/show_all_delivers';
$route['show-vendors'] = 'parcel_service/show_vendors';
$route['show-customers'] = 'parcel_service/show_customers';
$route['show-delivery-man'] = 'parcel_service/show_delivery_man';


$route['save-vendor'] = 'parcel_service/save_vendor';
$route['save-driveryman'] = 'parcel_service/save_driveryman';

//done


//ticketing
$route['show-ticket-booking-list'] = 'ticketing/show_ticket_booking_list';

$route['show-bus-vendor-list'] = 'ticketing/show_bus_vendor_list';
$route['show-bus-passenger-list'] = 'ticketing/show_bus_passenger_list';

// $route['show-bus-vendor-list'] = 'ticketing/show_bus_vendor_list';
$route['show-train-passenger-list'] = 'ticketing/show_train_passenger_list';

// $route['show-bus-vendor-list'] = 'ticketing/show_bus_vendor_list';
$route['show-launch-passenger-list'] = 'ticketing/show_launch_passenger_list';

// $route['show-bus-vendor-list'] = 'ticketing/show_bus_vendor_list';
$route['show-airlines-passenger-list'] = 'ticketing/show_airlines_passenger_list';



$route['save-bus-travel-vendor'] = 'ticketing/save_bus_travel_vendor';
$route['save-ticketing-bus'] = 'ticketing/save_ticketing_bus';

//done



//food
$route['show-food-sales'] = 'food/show_food_sales';
$route['show-food-restaurant'] = 'food/show_food_restaurant';
$route['show-food-foodlist'] = 'food/show_food_foodlist';
$route['show-food-customer'] = 'food/show_food_customer';
$route['show-food-delivery-man'] = 'food/show_food_delivery_man';

$route['save-food-driveryman'] = 'food/save_food_driveryman';
$route['save-food-restaurant'] = 'food/save_food_restaurant';

//done


//donation
$route['show-donation-transaction-list'] = 'donation/show_donation_transaction_list';

$route['show-old-donor-list'] = 'donation/show_old_donor_list';
$route['show-orphanage-donor-list'] = 'donation/show_orphanage_donor_list';
$route['show-mosque-donor-list'] = 'donation/show_mosque_donor_list';
$route['show-madrasha-donor-list'] = 'donation/show_madrasha_donor_list';
$route['show-zaqat-donor-list'] = 'donation/show_zaqat_donor_list';
$route['show-quarbani-donor-list'] = 'donation/show_quarbani_donor_list';

$route['show-old-recipient-list'] = 'donation/show_old_recipient_list';
$route['show-orphanage-recipient-list'] = 'donation/show_orphanage_recipient_list';
$route['show-mosque-recipient-list'] = 'donation/show_mosque_recipient_list';
$route['show-madrasha-recipient-list'] = 'donation/show_madrasha_recipient_list';
$route['show-zaqat-recipient-list'] = 'donation/show_zaqat_recipient_list';
$route['show-quarbani-recipient-list'] = 'donation/show_quarbani_recipient_list';

//done

$route['show-bike'] = 'admin/show_bike';
$route['delete-bike/(.+)'] = 'admin/delete_bike/$1';
 




$route['dashboard'] = 'admin/dashboard';


