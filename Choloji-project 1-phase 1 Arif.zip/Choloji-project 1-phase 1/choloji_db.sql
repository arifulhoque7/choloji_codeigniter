-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 19, 2021 at 09:45 AM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `choloji_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bike_db`
--

DROP TABLE IF EXISTS `bike_db`;
CREATE TABLE IF NOT EXISTS `bike_db` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pickup_location` varchar(50) NOT NULL,
  `number_of_passenger` varchar(20) NOT NULL,
  `pickup_date` varchar(15) NOT NULL,
  `pickup_time` varchar(15) NOT NULL,
  `p_mobile` varchar(11) NOT NULL,
  `driver_name` varchar(20) NOT NULL,
  `d_mobile` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bike_db`
--

INSERT INTO `bike_db` (`id`, `name`, `pickup_location`, `number_of_passenger`, `pickup_date`, `pickup_time`, `p_mobile`, `driver_name`, `d_mobile`) VALUES
(15, 'imon', '236,shawrapara', '6', '23/2/2021', '3:36', '0178965', 'manik ', '0179685363'),
(14, 'imon', '236,shawrapara', '6', '23/2/2021', '3:36', '0178965', 'manik ', '0179685363');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
CREATE TABLE IF NOT EXISTS `cars` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `car_name` varchar(30) NOT NULL,
  `car_cost` int(11) NOT NULL,
  `car_image` varchar(45) NOT NULL,
  `car_class` varchar(20) NOT NULL,
  `car_booking_type` varchar(30) NOT NULL,
  `car_service_cost` int(11) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`car_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `car_name`, `car_cost`, `car_image`, `car_class`, `car_booking_type`, `car_service_cost`, `created`) VALUES
(31, 'ararr', 4, './car_image/a1779469efab70f3ff3eb39f5a85b102.', 'Large MPV', 'dfdfdf', 2424, '2021-03-02'),
(30, 'Toyota', 256, './car_image/b72f0499e39b8a5face15f7825127a58.', 'mid-size luxury', 'ffgf', 698, '2021-03-02'),
(29, 'ferari', 256, './car_image/feb6dbe333919e7993470911ffb77488.', 'D-segment', '1 person ', 265, '2021-03-02'),
(39, 'marcedes', 23, './car_image/f863ac87965b20ea054a9724a9bfeafe.', 'Premium compact', 'xfddd', 6, '2021-03-13'),
(40, 'aSAS', 4525, './car_image/523ac397d810b7950337ea3216e5bccd.', 'B-segment', '5353535', 545, '2021-03-13');

-- --------------------------------------------------------

--
-- Table structure for table `car_driver`
--

DROP TABLE IF EXISTS `car_driver`;
CREATE TABLE IF NOT EXISTS `car_driver` (
  `driver_id` int(11) NOT NULL AUTO_INCREMENT,
  `driver_photo` varchar(150) NOT NULL,
  `driver_name` varchar(20) NOT NULL,
  `driver_phone` int(11) NOT NULL,
  `driver_nid` int(11) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`driver_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_driver`
--

INSERT INTO `car_driver` (`driver_id`, `driver_photo`, `driver_name`, `driver_phone`, `driver_nid`, `created_date`) VALUES
(9, './car_driver_image/08b1ad24243e9706730bc3978f1a563d.jpg', 'abdullah', 175655, 665767, '2021-03-13'),
(8, './car_driver_image/fcfc298f06c87af3bb4f8b996b2675fe.jpg', 'john ', 415745114, 2147483647, '2021-03-04'),
(5, './car_driver_image/08ee4822d786decbe3f869f93010d6fa.jpg', 'anam', 1214555, 145454545, '2021-03-02');

-- --------------------------------------------------------

--
-- Table structure for table `car_passsengers`
--

DROP TABLE IF EXISTS `car_passsengers`;
CREATE TABLE IF NOT EXISTS `car_passsengers` (
  `car_pass_id` int(11) NOT NULL AUTO_INCREMENT,
  `car_pass_photo` varchar(50) NOT NULL,
  `car_pass_name` varchar(30) NOT NULL,
  `car_pass_email` varchar(30) NOT NULL,
  `car_pass_phone` int(11) NOT NULL,
  `car_pass_created` date NOT NULL,
  PRIMARY KEY (`car_pass_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_passsengers`
--

INSERT INTO `car_passsengers` (`car_pass_id`, `car_pass_photo`, `car_pass_name`, `car_pass_email`, `car_pass_phone`, `car_pass_created`) VALUES
(1, 'hvgh', 'abdur rahman ', 'ar@gmail.com', 128292, '2021-03-02'),
(2, 'hvgh', 'abdur rahman ', 'ar@gmail.com', 128292, '2021-03-02');

-- --------------------------------------------------------

--
-- Table structure for table `car_riders`
--

DROP TABLE IF EXISTS `car_riders`;
CREATE TABLE IF NOT EXISTS `car_riders` (
  `ride_id` int(11) NOT NULL AUTO_INCREMENT,
  `rider_name` varchar(20) NOT NULL,
  `driver_name` varchar(20) NOT NULL,
  `loc_to` varchar(80) NOT NULL,
  `loc_from` varchar(80) NOT NULL,
  `bill` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`ride_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_riders`
--

INSERT INTO `car_riders` (`ride_id`, `rider_name`, `driver_name`, `loc_to`, `loc_from`, `bill`, `rate`, `created`) VALUES
(1, 'amanat ullah', 'manik mia', 'mirpur ', 'jatrabari', 252, 48, '2021-03-01'),
(2, 'amanat ullah', 'manik mia', 'mirpur ', 'jatrabari', 252, 48, '2021-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `donation_donor_madrasha`
--

DROP TABLE IF EXISTS `donation_donor_madrasha`;
CREATE TABLE IF NOT EXISTS `donation_donor_madrasha` (
  `donor_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_name` text NOT NULL,
  `donor_address` text NOT NULL,
  `donor_email` text NOT NULL,
  `donor_phone` int(11) NOT NULL,
  `donor_amount` int(11) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_donor_madrasha`
--

INSERT INTO `donation_donor_madrasha` (`donor_id`, `donor_name`, `donor_address`, `donor_email`, `donor_phone`, `donor_amount`) VALUES
(1, 'Udar Manush', 'mirpur', 'udar@gmail.com', 5514, 124);

-- --------------------------------------------------------

--
-- Table structure for table `donation_donor_mosque`
--

DROP TABLE IF EXISTS `donation_donor_mosque`;
CREATE TABLE IF NOT EXISTS `donation_donor_mosque` (
  `donor_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_name` text NOT NULL,
  `donor_address` text NOT NULL,
  `donor_email` text NOT NULL,
  `donor_phone` int(11) NOT NULL,
  `donor_amount` int(11) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_donor_mosque`
--

INSERT INTO `donation_donor_mosque` (`donor_id`, `donor_name`, `donor_address`, `donor_email`, `donor_phone`, `donor_amount`) VALUES
(1, 'Udar Manush', 'mirpur', 'udar@gmail.com', 5514, 124);

-- --------------------------------------------------------

--
-- Table structure for table `donation_donor_old`
--

DROP TABLE IF EXISTS `donation_donor_old`;
CREATE TABLE IF NOT EXISTS `donation_donor_old` (
  `donor_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_name` text NOT NULL,
  `donor_address` text NOT NULL,
  `donor_email` text NOT NULL,
  `donor_phone` int(11) NOT NULL,
  `donor_amount` int(11) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_donor_old`
--

INSERT INTO `donation_donor_old` (`donor_id`, `donor_name`, `donor_address`, `donor_email`, `donor_phone`, `donor_amount`) VALUES
(1, 'Udar Manush', 'mirpur', 'udar@gmail.com', 5514, 124);

-- --------------------------------------------------------

--
-- Table structure for table `donation_donor_orphanage`
--

DROP TABLE IF EXISTS `donation_donor_orphanage`;
CREATE TABLE IF NOT EXISTS `donation_donor_orphanage` (
  `donor_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_name` text NOT NULL,
  `donor_address` text NOT NULL,
  `donor_email` text NOT NULL,
  `donor_phone` int(11) NOT NULL,
  `donor_amount` int(11) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_donor_orphanage`
--

INSERT INTO `donation_donor_orphanage` (`donor_id`, `donor_name`, `donor_address`, `donor_email`, `donor_phone`, `donor_amount`) VALUES
(1, 'Udar Manush', 'mirpur', 'udar@gmail.com', 5514, 124);

-- --------------------------------------------------------

--
-- Table structure for table `donation_donor_quarbani`
--

DROP TABLE IF EXISTS `donation_donor_quarbani`;
CREATE TABLE IF NOT EXISTS `donation_donor_quarbani` (
  `donor_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_name` text NOT NULL,
  `donor_address` text NOT NULL,
  `donor_email` text NOT NULL,
  `donor_phone` int(11) NOT NULL,
  `donor_amount` int(11) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_donor_quarbani`
--

INSERT INTO `donation_donor_quarbani` (`donor_id`, `donor_name`, `donor_address`, `donor_email`, `donor_phone`, `donor_amount`) VALUES
(1, 'Udar Manush', 'mirpur', 'udar@gmail.com', 5514, 124);

-- --------------------------------------------------------

--
-- Table structure for table `donation_donor_zaqat`
--

DROP TABLE IF EXISTS `donation_donor_zaqat`;
CREATE TABLE IF NOT EXISTS `donation_donor_zaqat` (
  `donor_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_name` text NOT NULL,
  `donor_address` text NOT NULL,
  `donor_email` text NOT NULL,
  `donor_phone` int(11) NOT NULL,
  `donor_amount` int(11) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_donor_zaqat`
--

INSERT INTO `donation_donor_zaqat` (`donor_id`, `donor_name`, `donor_address`, `donor_email`, `donor_phone`, `donor_amount`) VALUES
(1, 'Udar Manush', 'mirpur', 'udar@gmail.com', 5514, 124);

-- --------------------------------------------------------

--
-- Table structure for table `donation_recipient_madrasha`
--

DROP TABLE IF EXISTS `donation_recipient_madrasha`;
CREATE TABLE IF NOT EXISTS `donation_recipient_madrasha` (
  `recipient_id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_name` text NOT NULL,
  `recipient_location` text NOT NULL,
  `recipient_phone_no` int(11) NOT NULL,
  `recipient_bank` text NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_recipient_madrasha`
--

INSERT INTO `donation_recipient_madrasha` (`recipient_id`, `recipient_name`, `recipient_location`, `recipient_phone_no`, `recipient_bank`, `amount`) VALUES
(1, 'amanda ', 'gulshan', 1234567899, 'pubali', 1450);

-- --------------------------------------------------------

--
-- Table structure for table `donation_recipient_mosque`
--

DROP TABLE IF EXISTS `donation_recipient_mosque`;
CREATE TABLE IF NOT EXISTS `donation_recipient_mosque` (
  `recipient_id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_name` text NOT NULL,
  `recipient_location` text NOT NULL,
  `recipient_phone_no` int(11) NOT NULL,
  `recipient_bank` text NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_recipient_mosque`
--

INSERT INTO `donation_recipient_mosque` (`recipient_id`, `recipient_name`, `recipient_location`, `recipient_phone_no`, `recipient_bank`, `amount`) VALUES
(1, 'amanda ', 'gulshan', 1234567899, 'pubali', 1450);

-- --------------------------------------------------------

--
-- Table structure for table `donation_recipient_old`
--

DROP TABLE IF EXISTS `donation_recipient_old`;
CREATE TABLE IF NOT EXISTS `donation_recipient_old` (
  `recipient_id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_name` text NOT NULL,
  `recipient_location` text NOT NULL,
  `recipient_phone_no` int(11) NOT NULL,
  `recipient_bank` text NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_recipient_old`
--

INSERT INTO `donation_recipient_old` (`recipient_id`, `recipient_name`, `recipient_location`, `recipient_phone_no`, `recipient_bank`, `amount`) VALUES
(1, 'amanda ', 'gulshan', 1234567899, 'pubali', 1450);

-- --------------------------------------------------------

--
-- Table structure for table `donation_recipient_orphanage`
--

DROP TABLE IF EXISTS `donation_recipient_orphanage`;
CREATE TABLE IF NOT EXISTS `donation_recipient_orphanage` (
  `recipient_id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_name` text NOT NULL,
  `recipient_location` text NOT NULL,
  `recipient_phone_no` int(11) NOT NULL,
  `recipient_bank` text NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_recipient_orphanage`
--

INSERT INTO `donation_recipient_orphanage` (`recipient_id`, `recipient_name`, `recipient_location`, `recipient_phone_no`, `recipient_bank`, `amount`) VALUES
(1, 'amanda ', 'gulshan', 1234567899, 'pubali', 1450);

-- --------------------------------------------------------

--
-- Table structure for table `donation_recipient_quarbani`
--

DROP TABLE IF EXISTS `donation_recipient_quarbani`;
CREATE TABLE IF NOT EXISTS `donation_recipient_quarbani` (
  `recipient_id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_name` text NOT NULL,
  `recipient_location` text NOT NULL,
  `recipient_phone_no` int(11) NOT NULL,
  `recipient_bank` text NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_recipient_quarbani`
--

INSERT INTO `donation_recipient_quarbani` (`recipient_id`, `recipient_name`, `recipient_location`, `recipient_phone_no`, `recipient_bank`, `amount`) VALUES
(1, 'amanda ', 'gulshan', 1234567899, 'pubali', 1450);

-- --------------------------------------------------------

--
-- Table structure for table `donation_recipient_zaqat`
--

DROP TABLE IF EXISTS `donation_recipient_zaqat`;
CREATE TABLE IF NOT EXISTS `donation_recipient_zaqat` (
  `recipient_id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_name` text NOT NULL,
  `recipient_location` text NOT NULL,
  `recipient_phone_no` int(11) NOT NULL,
  `recipient_bank` text NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_recipient_zaqat`
--

INSERT INTO `donation_recipient_zaqat` (`recipient_id`, `recipient_name`, `recipient_location`, `recipient_phone_no`, `recipient_bank`, `amount`) VALUES
(1, 'amanda ', 'gulshan', 1234567899, 'pubali', 1450);

-- --------------------------------------------------------

--
-- Table structure for table `donation_transaction`
--

DROP TABLE IF EXISTS `donation_transaction`;
CREATE TABLE IF NOT EXISTS `donation_transaction` (
  `donation_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor` text NOT NULL,
  `recipient` text NOT NULL,
  `donation_type` text NOT NULL,
  `donation_amount` int(11) NOT NULL,
  `donation_transaction` int(11) NOT NULL,
  PRIMARY KEY (`donation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_transaction`
--

INSERT INTO `donation_transaction` (`donation_id`, `donor`, `recipient`, `donation_type`, `donation_amount`, `donation_transaction`) VALUES
(1, 'Guljar', 'Aminul Islam', 'Old Donation', 3444, 283721893),
(2, 'Guljar', 'Aminul Islam', 'Old Donation', 3444, 283721893);

-- --------------------------------------------------------

--
-- Table structure for table `food_customer`
--

DROP TABLE IF EXISTS `food_customer`;
CREATE TABLE IF NOT EXISTS `food_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_photo` varchar(50) NOT NULL,
  `customer_name` varchar(20) NOT NULL,
  `customer_email` varchar(20) NOT NULL,
  `customer_phone` int(11) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_customer`
--

INSERT INTO `food_customer` (`customer_id`, `customer_photo`, `customer_name`, `customer_email`, `customer_phone`, `created`) VALUES
(1, 'somethind here', 'azmol hossain ', 'ah@gmail.com', 175785455, '2021-02-02');

-- --------------------------------------------------------

--
-- Table structure for table `food_deliveryman`
--

DROP TABLE IF EXISTS `food_deliveryman`;
CREATE TABLE IF NOT EXISTS `food_deliveryman` (
  `deliveryman_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveryman_photo` varchar(300) NOT NULL,
  `deliveryman_name` varchar(20) NOT NULL,
  `deliveryman_phone` int(11) NOT NULL,
  `deliveryman_nid` int(11) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`deliveryman_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_deliveryman`
--

INSERT INTO `food_deliveryman` (`deliveryman_id`, `deliveryman_photo`, `deliveryman_name`, `deliveryman_phone`, `deliveryman_nid`, `created_date`) VALUES
(10, './parcel_deliveryman_image/eadc8fcb0c8eba0d83e3584409992233.jpg', 'manik mia ', 415745114, 455454, '2021-03-05'),
(11, './parcel_deliveryman_image/571f2290a790d95ef429db62af260a6e.png', 'kabir sing', 415745114, 232424434, '2021-03-05'),
(12, '', 'nVID2', 415745114, 45544, '2021-03-12'),
(13, '', 'nVID', 1766212263, 3, '2021-03-12'),
(14, './food_deliveryman_image/d1e1f0ae80ec391de0e3867f29f60bf0.jpg', 'kabir sing', 415745114, 45454, '2021-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `food_list`
--

DROP TABLE IF EXISTS `food_list`;
CREATE TABLE IF NOT EXISTS `food_list` (
  `food_id` int(11) NOT NULL AUTO_INCREMENT,
  `food_name` text NOT NULL,
  `food_quantity` int(11) NOT NULL,
  `food_unit` int(11) NOT NULL,
  `food_price` int(11) NOT NULL,
  PRIMARY KEY (`food_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `food_restaurant`
--

DROP TABLE IF EXISTS `food_restaurant`;
CREATE TABLE IF NOT EXISTS `food_restaurant` (
  `restaurant_id` int(11) NOT NULL AUTO_INCREMENT,
  `restaurant_name` text NOT NULL,
  `restaurant_address` text NOT NULL,
  `restaurant_map_address` text NOT NULL,
  `restaurant_coupons` text NOT NULL,
  `restaurant_delivery_fee` int(11) NOT NULL,
  `restaurant_tax` int(11) NOT NULL,
  `restaurant_tin` int(11) NOT NULL,
  PRIMARY KEY (`restaurant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_restaurant`
--

INSERT INTO `food_restaurant` (`restaurant_id`, `restaurant_name`, `restaurant_address`, `restaurant_map_address`, `restaurant_coupons`, `restaurant_delivery_fee`, `restaurant_tax`, `restaurant_tin`) VALUES
(1, 'chillox', 'mawa ghat', '60,feet road', '565fd', 280, 12424242, 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `food_sales`
--

DROP TABLE IF EXISTS `food_sales`;
CREATE TABLE IF NOT EXISTS `food_sales` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `buyer_name` text NOT NULL,
  `seller_name` text NOT NULL,
  `order_time` time NOT NULL,
  `delivery_time` time NOT NULL,
  `food_id` int(11) NOT NULL,
  `delivery_location` text NOT NULL,
  `restaurant_location` text NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  PRIMARY KEY (`sale_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_sales`
--

INSERT INTO `food_sales` (`sale_id`, `buyer_name`, `seller_name`, `order_time`, `delivery_time`, `food_id`, `delivery_location`, `restaurant_location`, `buyer_id`, `seller_id`) VALUES
(1, 'akramul hoq', 'chillox', '12:25:46', '20:25:46', 1, 'mirpur', 'dhanmondi', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `parcel_customer`
--

DROP TABLE IF EXISTS `parcel_customer`;
CREATE TABLE IF NOT EXISTS `parcel_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_photo` varchar(50) NOT NULL,
  `customer_name` varchar(20) NOT NULL,
  `customer_email` varchar(20) NOT NULL,
  `customer_phone` int(11) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parcel_customer`
--

INSERT INTO `parcel_customer` (`customer_id`, `customer_photo`, `customer_name`, `customer_email`, `customer_phone`, `created`) VALUES
(1, 'somethind here', 'azmol hossain ', 'ah@gmail.com', 175785455, '2021-02-02');

-- --------------------------------------------------------

--
-- Table structure for table `parcel_deliver`
--

DROP TABLE IF EXISTS `parcel_deliver`;
CREATE TABLE IF NOT EXISTS `parcel_deliver` (
  `deliver_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliver_from` varchar(50) NOT NULL,
  `deliver_to` varchar(50) NOT NULL,
  `customer` varchar(20) NOT NULL,
  `vendor` varchar(20) NOT NULL,
  `delivery_man` varchar(20) NOT NULL,
  `distance` varchar(20) NOT NULL,
  `charge_amount` int(11) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `rating` varchar(20) NOT NULL,
  PRIMARY KEY (`deliver_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parcel_deliver`
--

INSERT INTO `parcel_deliver` (`deliver_id`, `deliver_from`, `deliver_to`, `customer`, `vendor`, `delivery_man`, `distance`, `charge_amount`, `payment_status`, `payment_method`, `rating`) VALUES
(1, 'mirpur', 'dhanmondi', 'anamul hoque', 'toshiba', 'amanat ullah', '20km', 201, 'paid', 'bKash', '2 star'),
(3, 'mohkahali ', 'mohammedpur', 'baki billah', 'shomrat mia ', 'gaitonde ', '32m', 120, 'unpaid', 'cash', '5 star');

-- --------------------------------------------------------

--
-- Table structure for table `parcel_deliveryman`
--

DROP TABLE IF EXISTS `parcel_deliveryman`;
CREATE TABLE IF NOT EXISTS `parcel_deliveryman` (
  `deliveryman_id` int(11) NOT NULL AUTO_INCREMENT,
  `deliveryman_photo` varchar(300) NOT NULL,
  `deliveryman_name` varchar(20) NOT NULL,
  `deliveryman_phone` int(11) NOT NULL,
  `deliveryman_nid` int(11) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`deliveryman_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parcel_deliveryman`
--

INSERT INTO `parcel_deliveryman` (`deliveryman_id`, `deliveryman_photo`, `deliveryman_name`, `deliveryman_phone`, `deliveryman_nid`, `created_date`) VALUES
(10, './parcel_deliveryman_image/eadc8fcb0c8eba0d83e3584409992233.jpg', 'manik mia ', 415745114, 455454, '2021-03-05'),
(11, './parcel_deliveryman_image/571f2290a790d95ef429db62af260a6e.png', 'kabir sing', 415745114, 232424434, '2021-03-05');

-- --------------------------------------------------------

--
-- Table structure for table `parcel_vendor`
--

DROP TABLE IF EXISTS `parcel_vendor`;
CREATE TABLE IF NOT EXISTS `parcel_vendor` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(20) NOT NULL,
  `vendor_address` varchar(50) NOT NULL,
  `vendor_contact` int(11) NOT NULL,
  `vendor_license` varchar(20) NOT NULL,
  `vendor_year` int(11) NOT NULL,
  `vendor_type` varchar(20) NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parcel_vendor`
--

INSERT INTO `parcel_vendor` (`vendor_id`, `vendor_name`, `vendor_address`, `vendor_contact`, `vendor_license`, `vendor_year`, `vendor_type`) VALUES
(1, 'akash DTH', 'nilkhet', 155488, '5245455445454', 2, '3'),
(2, 'projapoti telicom', 'uttara', 1454545, '454445445445', 3, 'ffdssdfs'),
(3, 'nagad', 'purbachal dhaka', 155488, '323343443', 6, 'gfgdfgd'),
(4, 'akash DTH 2', 'nilkhet', 155488, '324243444', 23442424, 'vcvffvs');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `admin_name` varchar(20) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `username`, `password`, `admin_name`) VALUES
(1, 'admin@2021', 'admin123', 'Arif');

-- --------------------------------------------------------

--
-- Table structure for table `ticketing_airlines_passengers`
--

DROP TABLE IF EXISTS `ticketing_airlines_passengers`;
CREATE TABLE IF NOT EXISTS `ticketing_airlines_passengers` (
  `passenger_id` int(11) NOT NULL AUTO_INCREMENT,
  `passenger_name` varchar(20) NOT NULL,
  `passenger_email` varchar(20) NOT NULL,
  `passenger_phone` int(11) NOT NULL,
  `passenger_address` varchar(20) NOT NULL,
  `passenger_created` date NOT NULL,
  PRIMARY KEY (`passenger_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketing_airlines_passengers`
--

INSERT INTO `ticketing_airlines_passengers` (`passenger_id`, `passenger_name`, `passenger_email`, `passenger_phone`, `passenger_address`, `passenger_created`) VALUES
(1, 'Aminul Hoque', 'aminul@gmail.com', 54845454, 'amaasdsa', '2021-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `ticketing_booking`
--

DROP TABLE IF EXISTS `ticketing_booking`;
CREATE TABLE IF NOT EXISTS `ticketing_booking` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_type` varchar(20) NOT NULL,
  `vehicle_type` varchar(20) NOT NULL,
  `booking_number` int(11) NOT NULL,
  `travel_agency_name` varchar(30) NOT NULL,
  `vehicle_number` varchar(20) NOT NULL,
  `booking_from` varchar(50) NOT NULL,
  `booking_to` varchar(50) NOT NULL,
  `amount_charged` int(11) NOT NULL,
  `comission_amount` int(11) NOT NULL,
  `distance` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketing_booking`
--

INSERT INTO `ticketing_booking` (`booking_id`, `booking_type`, `vehicle_type`, `booking_number`, `travel_agency_name`, `vehicle_number`, `booking_from`, `booking_to`, `amount_charged`, `comission_amount`, `distance`, `date`, `time`) VALUES
(1, 'minimal', 'plane', 125, 'apps', 'dh554545', 'amtoli', 'radio center', 25, 10, '32m', '2021-03-02', '11:13:02'),
(2, 'minimal', 'plane', 125, 'apps', 'dh554545', 'amtoli', 'radio center', 25, 10, '32m', '2021-03-02', '11:13:02');

-- --------------------------------------------------------

--
-- Table structure for table `ticketing_bus_list`
--

DROP TABLE IF EXISTS `ticketing_bus_list`;
CREATE TABLE IF NOT EXISTS `ticketing_bus_list` (
  `bus_id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_tin_id` int(11) NOT NULL,
  `bus_number` varchar(20) NOT NULL,
  `chesis_number` int(11) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketing_bus_list`
--

INSERT INTO `ticketing_bus_list` (`bus_id`, `owner_tin_id`, `bus_number`, `chesis_number`) VALUES
(1, 0, '20ah', 20155),
(2, 55, '25ah', 25),
(3, 55, '248ah', 5555),
(4, 852, '248ah', 544),
(5, 102, 'ss455', 5656),
(6, 456, 'r3422', 545435);

-- --------------------------------------------------------

--
-- Table structure for table `ticketing_bus_passengers`
--

DROP TABLE IF EXISTS `ticketing_bus_passengers`;
CREATE TABLE IF NOT EXISTS `ticketing_bus_passengers` (
  `passenger_id` int(11) NOT NULL AUTO_INCREMENT,
  `passenger_name` varchar(20) NOT NULL,
  `passenger_email` varchar(20) NOT NULL,
  `passenger_phone` int(11) NOT NULL,
  `passenger_address` varchar(20) NOT NULL,
  `passenger_created` date NOT NULL,
  PRIMARY KEY (`passenger_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketing_bus_passengers`
--

INSERT INTO `ticketing_bus_passengers` (`passenger_id`, `passenger_name`, `passenger_email`, `passenger_phone`, `passenger_address`, `passenger_created`) VALUES
(1, 'Aminul Hoque', 'aminul@gmail.com', 54845454, 'amaasdsa', '2021-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `ticketing_bus_vendor`
--

DROP TABLE IF EXISTS `ticketing_bus_vendor`;
CREATE TABLE IF NOT EXISTS `ticketing_bus_vendor` (
  `agency_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_name` varchar(20) NOT NULL,
  `agency_address` varchar(30) NOT NULL,
  `tin_id` int(11) NOT NULL,
  `owner_name` varchar(20) NOT NULL,
  `route_number` varchar(20) NOT NULL,
  `bus_from` varchar(50) NOT NULL,
  `bus_to` varchar(50) NOT NULL,
  `bus_via` varchar(30) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `phone_no` int(11) NOT NULL,
  PRIMARY KEY (`agency_id`),
  KEY `tin_id` (`tin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketing_bus_vendor`
--

INSERT INTO `ticketing_bus_vendor` (`agency_id`, `agency_name`, `agency_address`, `tin_id`, `owner_name`, `route_number`, `bus_from`, `bus_to`, `bus_via`, `payment_method`, `phone_no`) VALUES
(1, 'Ariful Hoque', '265,West Monipur,Mirpur-2, Dha', 55, 'dsds', '02', 'malibagh', 'mogbazar', 'sdsd', 'sdlksld', 1766212263),
(2, 'ENA', 'kalshi', 852, 'dsds', '2525', 'dfsdf', 'mogbazar', 'sdsd', 'sdlksld', 415745114),
(3, 'green ine', 'mawa ghat', 102, 'dsds', '142', 'dfsdf', 'mogbazar', 'sdsd', 'sdlksld', 155488),
(4, 'cxxz', 'sssad', 5455, '5456', '544', 'fgdg', 'fdgfdg', 'sdsd', 'sdlksld', 175655),
(5, 'agradud', 'mohakhali', 456, 'fghfh', '54', 'gulshan', 'mirpur', 'sdsd', 'sdlksld', 415745114);

-- --------------------------------------------------------

--
-- Table structure for table `ticketing_launch_passengers`
--

DROP TABLE IF EXISTS `ticketing_launch_passengers`;
CREATE TABLE IF NOT EXISTS `ticketing_launch_passengers` (
  `passenger_id` int(11) NOT NULL AUTO_INCREMENT,
  `passenger_name` varchar(20) NOT NULL,
  `passenger_email` varchar(20) NOT NULL,
  `passenger_phone` int(11) NOT NULL,
  `passenger_address` varchar(20) NOT NULL,
  `passenger_created` date NOT NULL,
  PRIMARY KEY (`passenger_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketing_launch_passengers`
--

INSERT INTO `ticketing_launch_passengers` (`passenger_id`, `passenger_name`, `passenger_email`, `passenger_phone`, `passenger_address`, `passenger_created`) VALUES
(1, 'Aminul Hoque', 'aminul@gmail.com', 54845454, 'amaasdsa', '2021-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `ticketing_train_passengers`
--

DROP TABLE IF EXISTS `ticketing_train_passengers`;
CREATE TABLE IF NOT EXISTS `ticketing_train_passengers` (
  `passenger_id` int(11) NOT NULL AUTO_INCREMENT,
  `passenger_name` varchar(20) NOT NULL,
  `passenger_email` varchar(20) NOT NULL,
  `passenger_phone` int(11) NOT NULL,
  `passenger_address` varchar(20) NOT NULL,
  `passenger_created` date NOT NULL,
  PRIMARY KEY (`passenger_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketing_train_passengers`
--

INSERT INTO `ticketing_train_passengers` (`passenger_id`, `passenger_name`, `passenger_email`, `passenger_phone`, `passenger_address`, `passenger_created`) VALUES
(1, 'Aminul Hoque', 'aminul@gmail.com', 54845454, 'amaasdsa', '2021-03-03');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
